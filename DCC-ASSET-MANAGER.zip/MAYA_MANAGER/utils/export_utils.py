# -*- coding: utf-8 -*-
"""
Maya Export Utils
Maya 导出工具
"""

import os

class MayaExportUtils:
    """Maya 导出工具类"""
    
    def __init__(self):
        self.supported_formats = ['FBX', 'Alembic', 'OBJ']
        # 记录最近一次非阻断告警信息，供UI显示
        self.last_warning_message = None
        # 记录最近一次导出生成的文件列表
        self._last_outputs = []
    
    def detect_maya(self):
        """检测是否在Maya环境中"""
        try:
            from importlib import import_module
            import_module('maya.cmds')
            return True
        except Exception:
            return False
    
    def get_selected_objects(self):
        """获取选中的对象"""
        if not self.detect_maya():
            return []

        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            # 1) 变换选择
            transforms = cmds.ls(selection=True, type='transform', long=True) or []
            if transforms:
                return transforms
            # 2) 形状选择 → 父级变换
            shapes = cmds.ls(selection=True, dag=True, shapes=True, long=True) or []
            parents = []
            for sh in shapes:
                p = cmds.listRelatives(sh, parent=True, fullPath=True) or []
                parents.extend(p)
            if parents:
                return sorted(list(set(parents)))
            # 3) 组件选择（.f[], .vtx[] 等）→ 所属形状父级变换
            comps = cmds.ls(selection=True, long=True) or []
            result = []
            for c in comps:
                try:
                    objs = cmds.ls(c, objectsOnly=True, long=True) or []
                    for obj in objs:
                        if cmds.nodeType(obj) == 'transform':
                            result.append(obj)
                        else:
                            p = cmds.listRelatives(obj, parent=True, fullPath=True) or []
                            result.extend(p)
                except Exception:
                    pass
            return sorted(list(set(result)))
        except Exception:
            return []

    def _ensure_plugin_loaded(self, plugin_name):
        """确保指定插件已加载"""
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            if not cmds.pluginInfo(plugin_name, query=True, loaded=True):
                try:
                    cmds.loadPlugin(plugin_name)
                except Exception:
                    return False
            return True
        except Exception:
            return False
    
    def check_pivot_at_origin(self, objects=None):
        """检查枢轴是否在原点"""
        if not self.detect_maya():
            return False
        
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            if objects is None:
                objects = self.get_selected_objects()
            
            if not objects:
                return False
            
            for obj in objects:
                pivot = cmds.xform(obj, query=True, worldSpace=True, rotatePivot=True)
                if abs(pivot[0]) > 0.001 or abs(pivot[1]) > 0.001 or abs(pivot[2]) > 0.001:
                    return False
            return True
        except:
            return False
    
    def move_to_world_origin(self, objects=None):
        """移动物体到世界原点"""
        if not self.detect_maya():
            return False
        
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            if objects is None:
                objects = self.get_selected_objects()
            
            if not objects:
                return False
            
            for obj in objects:
                pivot = cmds.xform(obj, query=True, worldSpace=True, rotatePivot=True)
                cmds.move(-pivot[0], -pivot[1], -pivot[2], obj, relative=True, worldSpace=True)
            
            return True
        except Exception as e:
            print(f"移动到原点失败: {e}")
            return False
    
    def set_pivot_position(self, position_type, objects=None):
        """设置枢轴位置
        
        Args:
            position_type: 位置类型 ('center', 'min', 'max', etc.)
            objects: 对象列表，如果为None则使用选中的对象
        """
        if not self.detect_maya():
            return False
        
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            if objects is None:
                objects = self.get_selected_objects()
            
            if not objects:
                return False
            
            position_mapping = {
                '几何中心': 'center',
                '左前下': 'min_min_min',
                '左前上': 'min_max_min',
                '左后下': 'min_min_max',
                '左后上': 'min_max_max',
                '右前下': 'max_min_min',
                '右前上': 'max_max_min',
                '右后下': 'max_min_max',
                '右后上': 'max_max_max'
            }
            
            pos_type = position_mapping.get(position_type, position_type)
            
            for obj in objects:
                bbox = cmds.exactWorldBoundingBox(obj)
                xmin, ymin, zmin, xmax, ymax, zmax = bbox
                
                if pos_type == 'center':
                    pos = [(xmin + xmax) / 2, (ymin + ymax) / 2, (zmin + zmax) / 2]
                elif pos_type == 'min_min_min':
                    pos = [xmin, ymin, zmin]
                elif pos_type == 'min_max_min':
                    pos = [xmin, ymax, zmin]
                elif pos_type == 'min_min_max':
                    pos = [xmin, ymin, zmax]
                elif pos_type == 'min_max_max':
                    pos = [xmin, ymax, zmax]
                elif pos_type == 'max_min_min':
                    pos = [xmax, ymin, zmin]
                elif pos_type == 'max_max_min':
                    pos = [xmax, ymax, zmin]
                elif pos_type == 'max_min_max':
                    pos = [xmax, ymin, zmax]
                elif pos_type == 'max_max_max':
                    pos = [xmax, ymax, zmax]
                else:
                    pos = [(xmin + xmax) / 2, (ymin + ymax) / 2, (zmin + zmax) / 2]
                
                cmds.xform(obj, worldSpace=True, rotatePivot=pos, scalePivot=pos)
            
            return True
        except Exception as e:
            print(f"设置枢轴位置失败: {e}")
            return False
    
    def export_fbx(self, file_path, objects=None):
        """导出FBX"""
        if not self.detect_maya():
            return False
        
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            # 加载FBX插件
            if not self._ensure_plugin_loaded('fbxmaya'):
                print('无法加载FBX插件(fbxmaya)')
                return False
            
            if objects:
                # 选择指定对象（仅导出这些）
                cmds.select(objects, replace=True)
            
            # 确保目录存在
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            # 导出FBX
            cmds.file(file_path, force=True, exportSelected=True, type="FBX export")
            return True
            
        except Exception as e:
            print(f"FBX 导出失败: {e}")
            return False
    
    def export_alembic(self, file_path, objects=None, frame_range=(1, 1)):
        """导出Alembic"""
        if not self.detect_maya():
            return False
        
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            # 加载Alembic插件
            if not self._ensure_plugin_loaded('AbcExport'):
                print('无法加载 Alembic 插件(AbcExport)')
                return False
            
            if objects is None:
                objects = self.get_selected_objects()
            
            if not objects:
                return False
            
            # 确保目录存在
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            # 构建导出参数
            # Alembic 需要指定 transform 的根；统一使用长路径
            root_list = " ".join([f"-root {obj}" for obj in (cmds.ls(objects, long=True) or objects)])
            job_arg = f'-frameRange {frame_range[0]} {frame_range[1]} {root_list} -file "{file_path}"'
            
            # 导出Alembic
            cmds.AbcExport(j=job_arg)
            return True
            
        except Exception as e:
            print(f"Alembic 导出失败: {e}")
            return False
    
    def export_obj(self, file_path, objects=None):
        """导出OBJ"""
        if not self.detect_maya():
            return False
        
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            
            if objects:
                # 选择指定对象（仅导出这些）
                cmds.select(objects, replace=True)
            
            # 确保目录存在
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            # 导出OBJ
            cmds.file(file_path, force=True, exportSelected=True, type="OBJexport")
            return True
            
        except Exception as e:
            print(f"OBJ 导出失败: {e}")
            return False
    
    def export_model(self, file_path, export_format, objects=None, **kwargs):
        """统一导出接口"""
        # 清空上一次的告警消息
        self.last_warning_message = None
        self._last_outputs = []
        # 在导出前，如果当前选择已归零，则检查场景中是否还有其它未归零的物体并给出警告（不阻断导出）
        try:
            if self.detect_maya():
                if objects is None:
                    objects = self.get_selected_objects()
                if objects and self.check_pivot_at_origin(objects):
                    self._warn_if_scene_has_non_zero_others(objects)
        except Exception:
            # 静默忽略检查中的异常，避免影响导出
            pass

        fmt = export_format.upper()
        merge = bool(kwargs.get('merge', True))
        # 若未提供 objects，则按当前选择
        if objects is None:
            objects = self.get_selected_objects()
        if not objects:
            return False

        def do_one(path, objs):
            if fmt == 'FBX':
                return self.export_fbx(path, objs)
            elif fmt == 'ALEMBIC':
                frame_range = kwargs.get('frame_range', (1, 1))
                return self.export_alembic(path, objs, frame_range)
            elif fmt == 'OBJ':
                return self.export_obj(path, objs)
            else:
                print(f"不支持的导出格式: {export_format}")
                return False

        # 合并导出：所有对象导成一个文件
        if merge or len(objects) == 1:
            ok = do_one(file_path, objects)
            if ok:
                self._last_outputs.append(file_path)
            return ok

        # 分别导出：逐个对象导出各自文件，文件名追加 __对象短名
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
        except Exception:
            return False

        import os as _os
        base, ext = _os.path.splitext(file_path)
        all_ok = True
        for obj in objects:
            try:
                short = cmds.ls(obj, shortNames=True)[0] if cmds.ls(obj, shortNames=True) else obj.split('|')[-1]
            except Exception:
                short = 'Object'
            out_path = f"{base}__{short}{ext}"
            ok = do_one(out_path, [obj])
            if ok:
                self._last_outputs.append(out_path)
            all_ok = all_ok and ok
        return all_ok
    
    def generate_filename(self, asset_type, asset_name, asset_id, export_format):
        """生成标准文件名"""
        def sanitize(s):
            return s.strip().replace(" ", "_")
        
        clean_type = sanitize(asset_type)
        clean_name = sanitize(asset_name)
        clean_id = sanitize(asset_id)
        
        if not (clean_type and clean_name and clean_id):
            return None
        
        extension = export_format.lower()
        if extension == 'alembic':
            extension = 'abc'
        elif extension == 'fbx':
            extension = 'fbx'
        elif extension == 'obj':
            extension = 'obj'
        
        return f"SC_{clean_type}_{clean_name}_{clean_id}.{extension}"
    
    def get_object_info(self, obj_name):
        """获取对象详细信息"""
        if not self.detect_maya():
            return None
        
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            
            info = {
                'name': obj_name,
                'type': cmds.nodeType(obj_name),
                'pivot': cmds.xform(obj_name, query=True, worldSpace=True, rotatePivot=True),
                'bbox': cmds.exactWorldBoundingBox(obj_name),
                'face_count': 0,
                'vertex_count': 0,
                'uv_sets': []
            }
            
            # 获取面数和顶点数
            shapes = cmds.listRelatives(obj_name, shapes=True, fullPath=True) or []
            for shape in shapes:
                if cmds.nodeType(shape) == 'mesh':
                    info['face_count'] += cmds.polyEvaluate(shape, face=True)
                    info['vertex_count'] += cmds.polyEvaluate(shape, vertex=True)
                    
                    # 获取UV集
                    try:
                        uv_sets = cmds.polyUVSet(shape, query=True, allUVSets=True) or []
                        info['uv_sets'].extend(uv_sets)
                    except:
                        pass
            
            return info
            
        except Exception as e:
            print(f"获取对象信息失败: {e}")
            return None

    def _warn_if_scene_has_non_zero_others(self, selected_objects, tolerance=0.001):
        """当选中对象已归零时，检查场景其它网格物体是否未归零，若存在则打印警告。

        仅作提醒，不影响导出流程。
        """
        if not self.detect_maya():
            return
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')

            # 统一为长路径，避免同名冲突
            selected_long = set(cmds.ls(selected_objects or [], long=True) or [])

            # 获取所有mesh的父级transform（忽略摄像机/组节点等非网格）
            mesh_shapes = cmds.ls(type='mesh', long=True) or []
            all_mesh_transforms = set()
            for sh in mesh_shapes:
                parents = cmds.listRelatives(sh, parent=True, fullPath=True) or []
                for p in parents:
                    all_mesh_transforms.add(p)

            # 其他对象 = 场景网格transform - 当前选中对象（按长路径）
            other_transforms = [t for t in all_mesh_transforms if t not in selected_long]

            if not other_transforms:
                return

            non_zero = []
            for obj in other_transforms:
                try:
                    pivot = cmds.xform(obj, query=True, worldSpace=True, rotatePivot=True)
                    if abs(pivot[0]) > tolerance or abs(pivot[1]) > tolerance or abs(pivot[2]) > tolerance:
                        non_zero.append(obj)
                except Exception:
                    # 无法查询时跳过
                    pass

            if non_zero:
                # 只展示前几个名字，避免刷屏
                sample = non_zero[:5]
                try:
                    short_names = [cmds.ls(n, shortNames=True)[0] if cmds.ls(n, shortNames=True) else n for n in sample]
                except Exception:
                    short_names = sample
                msg = (
                    f"警告：检测到场景中有 {len(non_zero)} 个物体枢轴未归零（不影响当前导出）。样例："
                    + ", ".join(short_names)
                )
                # 存储供UI读取
                self.last_warning_message = msg
                try:
                    cmds.warning(msg)
                except Exception:
                    # 退化为标准输出
                    print(msg)
        except Exception:
            # 任何异常都不影响导出
            pass

    def get_last_warning(self, clear=True):
        """获取最近一次非阻断告警文本。默认获取后清空。"""
        msg = self.last_warning_message
        if clear:
            self.last_warning_message = None
        return msg

    def get_last_outputs(self, clear=False):
        """获取最近一次导出生成的文件路径列表。"""
        outs = list(self._last_outputs)
        if clear:
            self._last_outputs = []
        return outs

    def probe_scene_non_zero_others(self, selected_objects=None, tolerance=0.001):
        """用于UI：探测场景中除所选对象之外是否存在枢轴未归零的网格对象。

        返回：
            - str: 需要显示的告警文本；
            - None: 没有发现问题或不在Maya环境中。
        """
        if not self.detect_maya():
            return None
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')

            if selected_objects is None:
                selected_objects = self.get_selected_objects()

            # 要求当前选择已归零，否则无需提示“其他未归零”
            if not selected_objects or not self.check_pivot_at_origin(selected_objects):
                return None

            selected_long = set(cmds.ls(selected_objects or [], long=True) or [])
            mesh_shapes = cmds.ls(type='mesh', long=True) or []
            all_mesh_transforms = set()
            for sh in mesh_shapes:
                parents = cmds.listRelatives(sh, parent=True, fullPath=True) or []
                for p in parents:
                    all_mesh_transforms.add(p)

            other_transforms = [t for t in all_mesh_transforms if t not in selected_long]
            if not other_transforms:
                return None

            non_zero = []
            for obj in other_transforms:
                try:
                    pivot = cmds.xform(obj, query=True, worldSpace=True, rotatePivot=True)
                    if abs(pivot[0]) > tolerance or abs(pivot[1]) > tolerance or abs(pivot[2]) > tolerance:
                        non_zero.append(obj)
                except Exception:
                    pass

            if not non_zero:
                return None

            sample = non_zero[:5]
            try:
                short_names = [cmds.ls(n, shortNames=True)[0] if cmds.ls(n, shortNames=True) else n for n in sample]
            except Exception:
                short_names = sample
            return (
                f"警告：检测到场景中有 {len(non_zero)} 个物体枢轴未归零（不影响当前导出）。样例："
                + ", ".join(short_names)
            )
        except Exception:
            return None