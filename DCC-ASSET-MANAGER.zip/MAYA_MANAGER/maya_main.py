"""
Maya Asset Manager - 主入口文件
管理 Maya 场景和资产
"""

from PySide6 import QtWidgets
from MAYA_MANAGER.ui.main_window import MayaManagerWindow

_maya_manager_window = None

def show_tool():
    """显示 Maya Asset Manager 工具"""
    global _maya_manager_window
    
    if not QtWidgets.QApplication.instance():
        app = QtWidgets.QApplication([])
    else:
        app = QtWidgets.QApplication.instance()

    try:
        if _maya_manager_window is not None:
            if _maya_manager_window.isVisible():
                _maya_manager_window.hide()
                return _maya_manager_window
            else:
                _maya_manager_window.show()
                _maya_manager_window.raise_()
                _maya_manager_window.activateWindow()
                return _maya_manager_window
    except Exception:
        pass

    try:
        if _maya_manager_window is not None:
            try:
                if _maya_manager_window.isVisible():
                    _maya_manager_window.hide()
                    return _maya_manager_window
            except Exception:
                pass
        _maya_manager_window = MayaManagerWindow()
        _maya_manager_window.show()
        _maya_manager_window.raise_()
        _maya_manager_window.activateWindow()
        return _maya_manager_window
    except Exception as e:
        QtWidgets.QMessageBox.critical(
            None, 
            "错误", 
            f"创建 Maya Asset Manager 窗口失败:\n{e}", 
            QtWidgets.QMessageBox.Ok
        )
        return None

if __name__ == "__main__":
    show_tool()
