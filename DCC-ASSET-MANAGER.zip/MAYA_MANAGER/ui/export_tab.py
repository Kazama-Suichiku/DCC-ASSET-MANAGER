# -*- coding: utf-8 -*-
"""
Export Tab
模型导出标签页
"""

import os
from PySide6 import QtWidgets, QtCore

from ..utils.export_utils import MayaExportUtils


class ExportTab(QtWidgets.QWidget):
    """模型导出Tab"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.utils = MayaExportUtils()
        self._init_ui()
        self._connect_signals()
        self._update_status()
        self._update_preview()
    
    def _init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # 场景告警横幅（显眼）
        self.scene_warning_label = QtWidgets.QLabel()
        self.scene_warning_label.setWordWrap(True)
        self.scene_warning_label.setVisible(False)
        self.scene_warning_label.setStyleSheet(
            "QLabel { background: #FFE08A; color: #222; border: 1px solid #D9A100;"
            " padding: 8px; font-weight: bold; }"
        )

        # 状态与快速操作
        status_group = QtWidgets.QGroupBox("状态与快速操作")
        status_layout = QtWidgets.QGridLayout(status_group)
        
        status_layout.addWidget(QtWidgets.QLabel("枢轴状态："), 0, 0)
        self.status_label = QtWidgets.QLabel("检测中…")
        self.status_label.setStyleSheet("QLabel { background: #5a5a5a; color: white; padding: 3px; }")
        status_layout.addWidget(self.status_label, 0, 1)
        
        self.btn_move_origin = QtWidgets.QPushButton("一键归到世界中心")
        status_layout.addWidget(self.btn_move_origin, 0, 2)
        
        status_layout.addWidget(QtWidgets.QLabel("枢轴位置："), 1, 0)
        self.pivot_combo = QtWidgets.QComboBox()
        self.pivot_combo.addItems([
            '几何中心', '左前下', '左前上', '左后下', '左后上',
            '右前下', '右前上', '右后下', '右后上'
        ])
        status_layout.addWidget(self.pivot_combo, 1, 1)
        
        self.btn_apply_pivot = QtWidgets.QPushButton("应用枢轴")
        status_layout.addWidget(self.btn_apply_pivot, 1, 2)
        # 手动刷新按钮
        self.btn_refresh_status = QtWidgets.QPushButton("刷新枢轴状态")
        status_layout.addWidget(self.btn_refresh_status, 2, 0, 1, 3)
        
        layout.addWidget(status_group)
        # 将告警横幅放在状态组后面，便于注意
        layout.addWidget(self.scene_warning_label)
        
        # 命名与导出设置
        settings_group = QtWidgets.QGroupBox("命名与导出设置")
        settings_layout = QtWidgets.QGridLayout(settings_group)
        
        rule_label = QtWidgets.QLabel("命名规则：SC_资产类型_资产名称_编号")
        rule_label.setAlignment(QtCore.Qt.AlignCenter)
        settings_layout.addWidget(rule_label, 0, 0, 1, 3)
        
        settings_layout.addWidget(QtWidgets.QLabel("资产类型："), 1, 0)
        self.asset_type_edit = QtWidgets.QLineEdit()
        settings_layout.addWidget(self.asset_type_edit, 1, 1, 1, 2)
        
        settings_layout.addWidget(QtWidgets.QLabel("资产名称："), 2, 0)
        self.asset_name_edit = QtWidgets.QLineEdit()
        settings_layout.addWidget(self.asset_name_edit, 2, 1, 1, 2)
        
        settings_layout.addWidget(QtWidgets.QLabel("资产编号："), 3, 0)
        self.asset_id_edit = QtWidgets.QLineEdit()
        settings_layout.addWidget(self.asset_id_edit, 3, 1, 1, 2)
        
        settings_layout.addWidget(QtWidgets.QLabel("导出格式："), 4, 0)
        self.format_combo = QtWidgets.QComboBox()
        self.format_combo.addItems(["FBX", "Alembic"])  # 与原工具一致
        settings_layout.addWidget(self.format_combo, 4, 1)
        
        settings_layout.addWidget(QtWidgets.QLabel("导出路径："), 5, 0)
        path_layout = QtWidgets.QHBoxLayout()
        self.path_edit = QtWidgets.QLineEdit(os.path.expanduser("~"))
        self.browse_btn = QtWidgets.QPushButton("浏览…")
        path_layout.addWidget(self.path_edit, 1)
        path_layout.addWidget(self.browse_btn)
        settings_layout.addLayout(path_layout, 5, 1, 1, 2)

        # 合并导出复选框与帮助按钮
        self.merge_checkbox = QtWidgets.QCheckBox("将所选对象合并导出为一个文件")
        self.merge_checkbox.setChecked(True)
        settings_layout.addWidget(self.merge_checkbox, 6, 0, 1, 2)
        self.help_btn = QtWidgets.QPushButton("导出帮助")
        settings_layout.addWidget(self.help_btn, 6, 2, 1, 1)
        
        layout.addWidget(settings_group)
        
        # 导出区域
        export_group = QtWidgets.QGroupBox("导出")
        export_layout = QtWidgets.QVBoxLayout(export_group)
        
        self.export_btn = QtWidgets.QPushButton("导出模型")
        self.export_btn.setEnabled(False)
        self.export_btn.setMinimumHeight(36)
        self.export_btn.setStyleSheet("QPushButton:disabled { background: #777; } QPushButton:enabled { background: #2d9932; color: white; font-weight: bold; }")
        export_layout.addWidget(self.export_btn)
        
        self.preview_label = QtWidgets.QLabel("导出文件名预览：")
        self.preview_label.setAlignment(QtCore.Qt.AlignCenter)
        export_layout.addWidget(self.preview_label)
        
        layout.addWidget(export_group)
        
        hint = QtWidgets.QLabel("提示：只有当枢轴位于 (0, 0, 0) 时才允许导出。")
        hint.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(hint)
    
    def _connect_signals(self):
        self.btn_move_origin.clicked.connect(self._on_move_to_origin)
        self.btn_apply_pivot.clicked.connect(self._on_apply_pivot)
        self.btn_refresh_status.clicked.connect(self._update_status)
        self.browse_btn.clicked.connect(self._on_browse)
        self.export_btn.clicked.connect(self._on_export)
        
        # 实时更新预览
        self.asset_type_edit.textChanged.connect(self._update_preview)
        self.asset_name_edit.textChanged.connect(self._update_preview)
        self.asset_id_edit.textChanged.connect(self._update_preview)
        self.format_combo.currentTextChanged.connect(self._update_preview)
        self.path_edit.textChanged.connect(self._update_preview)
        self.merge_checkbox.toggled.connect(self._update_preview)
        self.help_btn.clicked.connect(self._on_help)
    
    def _update_status(self):
        """更新枢轴状态与导出按钮状态"""
        try:
            at_origin = self.utils.check_pivot_at_origin()
            self.export_btn.setEnabled(bool(at_origin))
            self.status_label.setText("已归零" if at_origin else "未归零")
            self.status_label.setStyleSheet(
                "QLabel { background: #2d5a2d; color: white; padding: 3px; }" if at_origin else
                "QLabel { background: #8a3b3b; color: white; padding: 3px; }"
            )
            # 刷新场景未归零告警
            self._update_scene_warning()
        except Exception as e:
            self.status_label.setText(f"状态未知")
    
    def _update_scene_warning(self):
        """根据当前选择与场景情况显示/隐藏告警横幅"""
        try:
            msg = self.utils.probe_scene_non_zero_others()
        except Exception:
            msg = None
        if msg:
            self.scene_warning_label.setText(msg)
            self.scene_warning_label.setVisible(True)
        else:
            self.scene_warning_label.clear()
            self.scene_warning_label.setVisible(False)

    def _update_preview(self):
        """更新导出文件名预览"""
        name = self.utils.generate_filename(
            self.asset_type_edit.text(),
            self.asset_name_edit.text(),
            self.asset_id_edit.text(),
            self.format_combo.currentText()
        )
        folder = self.path_edit.text().strip() or ""
        if not name:
            self.preview_label.setText("导出文件名预览：请填写完整资产信息")
            return

        # 合并导出与分别导出预览
        try:
            selected = self.utils.get_selected_objects()
        except Exception:
            selected = []

        if self.merge_checkbox.isChecked() or not selected or len(selected) <= 1:
            self.preview_label.setText(f"导出文件名预览：{os.path.join(folder, name)}")
        else:
            # 多文件导出模式：展示一个示例
            try:
                sample = selected[0]
                # 取短名
                from importlib import import_module
                cmds = import_module('maya.cmds')
                short = cmds.ls(sample, shortNames=True)[0] if cmds.ls(sample, shortNames=True) else sample.split('|')[-1]
            except Exception:
                short = 'Object'
            base, ext = os.path.splitext(name)
            preview = f"{base}__{short}{ext}"
            self.preview_label.setText(
                f"导出文件名预览：将导出 {len(selected)} 个文件，示例：{os.path.join(folder, preview)}"
            )
    
    def _on_move_to_origin(self):
        if not self.utils.move_to_world_origin():
            QtWidgets.QMessageBox.warning(self, "警告", "请先在Maya中选择至少一个对象。")
        self._update_status()
    
    def _on_apply_pivot(self):
        choice = self.pivot_combo.currentText()
        if not self.utils.set_pivot_position(choice):
            QtWidgets.QMessageBox.warning(self, "警告", "请先在Maya中选择至少一个对象。")
        self._update_status()
    
    def _on_browse(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "选择导出路径", self.path_edit.text() or os.path.expanduser("~"))
        if folder:
            self.path_edit.setText(folder)
        self._update_preview()
    
    def _on_export(self):
        folder = self.path_edit.text().strip()
        if not folder:
            QtWidgets.QMessageBox.warning(self, "警告", "请先选择导出路径！")
            return
        
        filename = self.utils.generate_filename(
            self.asset_type_edit.text(),
            self.asset_name_edit.text(),
            self.asset_id_edit.text(),
            self.format_combo.currentText()
        )
        if not filename:
            QtWidgets.QMessageBox.warning(self, "警告", "请填写完整资产信息！")
            return
        
        full_path = os.path.join(folder, filename)
        fmt = self.format_combo.currentText()
        # 只导出选中的对象
        selected = self.utils.get_selected_objects()
        if not selected:
            QtWidgets.QMessageBox.warning(self, "警告", "请在Maya中选择至少一个对象后再导出。")
            return

        # 根据合并导出选项决定导出模式
        merge = self.merge_checkbox.isChecked()
        ok = self.utils.export_model(full_path, fmt, objects=selected, merge=merge)
        
        if ok:
            outputs = []
            try:
                outputs = self.utils.get_last_outputs() or []
            except Exception:
                outputs = []
            if not outputs:
                outputs = [full_path]
            if len(outputs) == 1:
                QtWidgets.QMessageBox.information(self, "完成", f"导出完成:\n{outputs[0]}")
            else:
                shown = "\n".join(outputs[:5])
                more = "" if len(outputs) <= 5 else f"\n... 共 {len(outputs)} 个文件"
                QtWidgets.QMessageBox.information(self, "完成", f"导出完成，多文件：\n{shown}{more}")
        else:
            QtWidgets.QMessageBox.critical(self, "失败", f"导出失败，请检查Maya控制台输出。")
        
        # 展示可能的场景级非阻断告警（优先取导出流程缓存的warning）
        try:
            msg = self.utils.get_last_warning(clear=True)
        except Exception:
            msg = None
        if not msg:
            try:
                msg = self.utils.probe_scene_non_zero_others()
            except Exception:
                msg = None
        if msg:
            self.scene_warning_label.setText(msg)
            self.scene_warning_label.setVisible(True)
        else:
            # 若无告警，按当前状态计算
            self._update_scene_warning()

        self._update_status()

    def _on_help(self):
        """导出工具使用帮助对话框"""
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("导出帮助")
        dlg.setModal(True)
        layout = QtWidgets.QVBoxLayout(dlg)

        text = QtWidgets.QTextBrowser()
        text.setOpenExternalLinks(True)
        text.setStyleSheet("QTextBrowser { background: transparent; }")
        text.setHtml(
            """
            <h3>模型导出工具使用说明</h3>
            <ol>
              <li><b>只导出所选对象：</b>导出时仅处理当前在 Maya 中选中的对象；未选择时无法导出。</li>
              <li><b>枢轴归零：</b>要求所选对象的枢轴在世界原点 (0,0,0) 才允许导出；可用“状态与快速操作”中的“应用枢轴/一键归到世界中心”。</li>
              <li><b>合并导出 vs 分别导出：</b>
                  勾选“将所选对象合并导出为一个文件”时，全部选中对象会被导出到 <i>一个</i> 文件；取消勾选时，会为每个选中对象导出 <i>各自</i> 的文件，文件名示例：<code>SC_类型_名称_编号__对象名.ext</code>。</li>
              <li><b>支持格式：</b>当前支持 FBX、Alembic（abc）。确保对应插件（fbxmaya/AbcExport）已安装；工具会自动尝试加载。</li>
              <li><b>非阻断场景警告：</b>当所选对象已归零，但场景中存在其他未归零网格时，会显示黄色警告横幅，但不阻断导出。</li>
            </ol>
            <p>命名规则：<code>SC_资产类型_资产名称_编号.扩展名</code>。分别导出时会在文件名后追加 <code>__对象名</code> 以区分。</p>
            """
        )
        layout.addWidget(text)

        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok)
        btns.accepted.connect(dlg.accept)
        layout.addWidget(btns)

        dlg.resize(560, 420)
        dlg.exec()
