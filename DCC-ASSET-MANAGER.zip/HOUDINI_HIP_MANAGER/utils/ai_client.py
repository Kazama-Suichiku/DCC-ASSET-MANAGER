# -*- coding: utf-8 -*-
"""
AI 调用客户端（Houdini 工具专用）
- OpenAI / DeepSeek：优先环境变量，其次 config/houdini_ai.ini
- Ollama：本地 HTTP /api/chat

安全提示：不要将密钥提交到版本库。建议使用环境变量 OPENAI_API_KEY、DEEPSEEK_API_KEY 或对应的 DCC_AI_* 变量。
"""

import os
import json
import ssl
from typing import List, Dict, Optional
from urllib import request, error

from shared.common_utils import load_config, save_config

# 尝试导入 requests（更好的 SSL 兼容性）
try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


class OpenAIClient:
    OPENAI_API_URL = "https://api.openai.com/v1/chat/completions"
    DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"

    def __init__(self, api_key: Optional[str] = None):
        # 兼容旧调用：传入 api_key 时视为 OpenAI 的密钥
        self._api_keys: Dict[str, Optional[str]] = {
            'openai': api_key or self._read_api_key('openai'),
            'deepseek': self._read_api_key('deepseek'),
        }
        # 创建 SSL 上下文（用于 HTTPS 请求）
        self._ssl_context = self._create_ssl_context()
        
        # 记录是否可用 requests 库（用于诊断）
        self._has_requests = HAS_REQUESTS

    def _create_ssl_context(self):
        """创建 SSL 上下文，兼容不同环境和旧版本 SSL"""
        try:
            # 尝试使用默认的 SSL 上下文
            context = ssl.create_default_context()
            # 设置更宽松的 SSL/TLS 版本选项（兼容性）
            context.minimum_version = ssl.TLSVersion.TLSv1_2
            context.check_hostname = True
            context.verify_mode = ssl.CERT_REQUIRED
            return context
        except Exception:
            pass
        
        try:
            # 降级方案：创建不验证证书的上下文
            context = ssl._create_unverified_context()
            # 尝试设置 TLS 1.2+ 协议
            try:
                context.minimum_version = ssl.TLSVersion.TLSv1_2
            except Exception:
                pass
            return context
        except Exception:
            pass
        
        # 最后的降级：尝试旧式 SSLContext
        try:
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            return context
        except Exception:
            return None

    # --- API Key 管理 ---
    def _read_api_key(self, provider: str) -> Optional[str]:
        provider = (provider or 'openai').lower()
        if provider == 'deepseek':
            key = os.environ.get('DEEPSEEK_API_KEY') or os.environ.get('DCC_AI_DEEPSEEK_API_KEY')
            if key:
                return key
        else:
            key = os.environ.get('OPENAI_API_KEY') or os.environ.get('DCC_AI_OPENAI_API_KEY')
            if key:
                return key

        cfg, _ = load_config('ai', dcc_type='houdini')
        if not cfg:
            return None
        if provider == 'deepseek':
            return cfg.get('deepseek_api_key') or None
        return cfg.get('openai_api_key') or None

    def has_api_key(self, provider: str = 'openai') -> bool:
        provider = (provider or 'openai').lower()
        return bool(self._api_keys.get(provider))

    def _get_api_key(self, provider: str) -> Optional[str]:
        provider = (provider or 'openai').lower()
        return self._api_keys.get(provider)

    def set_api_key(self, key: str, persist: bool = False, provider: str = 'openai') -> bool:
        provider = (provider or 'openai').lower()
        key = (key or '').strip()
        if not key:
            return False
        self._api_keys[provider] = key
        if persist:
            cfg, _ = load_config('ai', dcc_type='houdini')
            cfg = cfg or {}
            if provider == 'deepseek':
                cfg['deepseek_api_key'] = key
            else:
                cfg['openai_api_key'] = key
            ok, _ = save_config('ai', cfg, dcc_type='houdini')
            return ok
        return True

    def get_masked_key(self, provider: str = 'openai') -> str:
        provider = (provider or 'openai').lower()
        key = self._get_api_key(provider)
        if not key:
            return ''
        if len(key) <= 10:
            return '*' * len(key)
        return key[:5] + '...' + key[-4:]


    # --- Ollama base url ---
    def _ollama_base_url(self) -> str:
        # 优先环境变量，其次本地配置，最后默认
        env = os.environ.get('OLLAMA_HOST') or os.environ.get('OLLAMA_BASE_URL')
        if env:
            return env.rstrip('/')
        cfg, _ = load_config('ai', dcc_type='houdini')
        if cfg and cfg.get('ollama_base_url'):
            return str(cfg.get('ollama_base_url')).rstrip('/')
        return 'http://127.0.0.1:11434'

    def test_connection(self, provider: str = 'deepseek') -> Dict[str, any]:
        """测试 API 连接（用于诊断）"""
        provider = (provider or 'deepseek').lower()
        
        if provider == 'ollama':
            return self.ping_ollama()
        
        # 测试 OpenAI / DeepSeek
        if provider == 'deepseek':
            test_url = self.DEEPSEEK_API_URL
            vendor = 'DeepSeek'
        else:
            test_url = self.OPENAI_API_URL
            vendor = 'OpenAI'
        
        api_key = self._get_api_key(provider)
        if not api_key:
            return {'ok': False, 'error': f'缺少 {vendor} API Key'}
        
        try:
            # 简单的模型列表请求（如果 API 支持）或者发送一个最小的 chat 请求
            payload = {
                'model': 'deepseek-chat' if provider == 'deepseek' else 'gpt-4o-mini',
                'messages': [{'role': 'user', 'content': 'test'}],
                'max_tokens': 1
            }
            data = json.dumps(payload).encode('utf-8')
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {api_key}',
            }
            req = request.Request(test_url, data=data, headers=headers, method='POST')
            with request.urlopen(req, timeout=10, context=self._ssl_context) as resp:
                return {
                    'ok': True,
                    'message': f'{vendor} API 连接正常',
                    'url': test_url,
                    'status': resp.status
                }
        except error.HTTPError as e:
            return {
                'ok': False,
                'error': f'{vendor} HTTP {e.code}',
                'url': test_url,
                'details': str(e)
            }
        except Exception as e:
            return {
                'ok': False,
                'error': f'{vendor} 连接失败: {str(e)}',
                'url': test_url,
                'details': str(e)
            }

    def ping_ollama(self, timeout: int = 5) -> Dict[str, any]:
        base = self._ollama_base_url()
        url = base + '/api/version'
        try:
            req = request.Request(url, method='GET')
            with request.urlopen(req, timeout=timeout, context=self._ssl_context) as resp:
                text = resp.read().decode('utf-8')
                obj = json.loads(text)
            ver = obj.get('version') or text
            return {'ok': True, 'version': ver, 'base_url': base}
        except Exception as e:
            return {'ok': False, 'error': str(e), 'base_url': base}

    # --- Chat 接口 ---
    def chat(self,
             messages: List[Dict[str, str]],
             model: str = 'gpt-4o-mini',
             temperature: float = 0.3,
             max_tokens: Optional[int] = None,
             provider: str = 'openai',
             timeout: int = 60) -> Dict[str, any]:
        """调用 OpenAI Chat Completions 接口。

        Args:
            messages: 对话消息列表
            model: 模型名称
            temperature: 温度参数（0-1）
            max_tokens: 最大 token 数（None=自动）
            provider: 提供商（openai/deepseek/ollama）
            timeout: 超时时间（秒），默认 60s（DeepSeek 建议使用更长超时）

        返回：{ 'ok': bool, 'content': str | None, 'error': str | None, 'raw': dict | None }
        """
        provider = (provider or 'openai').lower()

        # --- Ollama (本地免费) ---
        if provider == 'ollama':
            base = self._ollama_base_url()
            try:
                payload = {
                    'model': model,
                    'messages': messages,
                    'stream': False,
                }
                data = json.dumps(payload).encode('utf-8')
                req = request.Request(
                    base + '/api/chat',
                    data=data,
                    headers={'Content-Type': 'application/json'},
                    method='POST'
                )
                with request.urlopen(req, timeout=timeout, context=self._ssl_context) as resp:
                    text = resp.read().decode('utf-8')
                    obj = json.loads(text)
                # Ollama 返回格式：{ message: { role, content }, done: bool, ... }
                content = None
                try:
                    content = (obj.get('message') or {}).get('content')
                except Exception:
                    content = None
                return {'ok': bool(content), 'content': content, 'error': None if content else '返回内容为空', 'raw': obj}
            except Exception as e:
                hint = (
                    '无法连接本地 Ollama 服务。\n'
                    f"地址：{base} \n"
                    '请确认：\n'
                    '1) 已安装并启动 Ollama（Windows 安装后可运行 `ollama serve`）。\n'
                    '2) 已拉取模型（如：`ollama pull llama3.1:8b-instruct`）。\n'
                    '3) 防火墙未拦截本机 11434 端口；如你修改了端口/地址，请在环境变量 OLLAMA_HOST 或 config/houdini_ai.ini 中设置 ollama_base_url。\n'
                )
                return {
                    'ok': False,
                    'content': None,
                    'error': hint + str(e),
                    'raw': None,
                }


        # --- OpenAI / DeepSeek (云端) ---
        api_key = self._get_api_key(provider)
        if provider in ('openai', 'deepseek') and not api_key:
            friendly_name = 'OpenAI' if provider == 'openai' else 'DeepSeek'
            return {'ok': False, 'content': None, 'error': f'缺少 {friendly_name} API Key', 'raw': None}

        if provider == 'deepseek':
            api_url = self.DEEPSEEK_API_URL
        else:
            api_url = self.OPENAI_API_URL

        # 验证 URL 格式
        if not api_url or not api_url.startswith(('http://', 'https://')):
            return {
                'ok': False,
                'content': None,
                'error': f'API URL 格式错误：{api_url}。请检查配置。',
                'raw': None
            }
        
        # 额外验证：检查 URL 是否有明显的格式错误
        if 'comv1' in api_url or 'com//' in api_url:
            return {
                'ok': False,
                'content': None,
                'error': f'API URL 格式异常（可能缺少斜杠）：{api_url}。\n请确保代码版本正确，建议重新加载模块。',
                'raw': None
            }

        payload = {
            'model': model,
            'messages': messages,
            'temperature': temperature,
        }
        if max_tokens is not None:
            payload['max_tokens'] = max_tokens

        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {api_key}',
        }

        # 优先使用 requests 库（更好的 SSL 兼容性）
        if HAS_REQUESTS:
            # 禁用系统代理（如果代理无法连接会导致问题）
            proxies = {
                'http': None,
                'https': None,
            }
            
            # 超时重试机制（针对 DeepSeek 服务器不稳定问题）
            max_attempts = 2
            retry_count = 0
            for attempt in range(max_attempts):
                try:
                    response = requests.post(
                        api_url,
                        json=payload,
                        headers=headers,
                        timeout=timeout,  # 使用参数指定的超时
                        verify=True,  # 验证 SSL 证书
                        proxies=proxies  # 禁用代理
                    )
                    response.raise_for_status()
                    obj = response.json()
                    
                    # 成功，提取内容并返回
                    try:
                        content = obj['choices'][0]['message']['content']
                    except Exception:
                        content = None
                    
                    result = {'ok': bool(content), 'content': content, 'error': None if content else '返回内容为空', 'raw': obj}
                    # 如果有重试过，添加提示信息
                    if retry_count > 0:
                        result['info'] = f'✓ 请求成功（经过 {retry_count} 次重试）'
                    return result
                    
                except (requests.exceptions.Timeout, requests.exceptions.ReadTimeout) as timeout_err:
                    if attempt < max_attempts - 1:
                        # 还有重试机会，继续
                        retry_count += 1
                        continue
                    else:
                        # 最后一次尝试也失败了，作为一般超时错误处理
                        vendor = 'OpenAI' if provider == 'openai' else 'DeepSeek'
                        return {
                            'ok': False,
                            'content': None,
                            'error': (
                                f'{vendor} 请求超时（已自动重试 {max_attempts} 次）\n\n'
                                f'可能原因：\n'
                                f'1. 网络连接不稳定\n'
                                f'2. 服务器响应慢（DeepSeek 服务器有时会较慢）\n'
                                f'3. 请求的内容过长，处理时间超过 {timeout} 秒\n\n'
                                f'建议：\n'
                                f'- 检查网络连接\n'
                                f'- 开启"快速模式"使用更短的 system prompt\n'
                                f'- 尝试将大任务拆分成多个小请求\n'
                                f'- 或使用本地 Ollama 模型\n\n'
                                f'技术详情：{str(timeout_err)}'
                            ),
                            'raw': None
                        }
                        
                except requests.exceptions.SSLError as e:
                    # SSL 错误，尝试禁用证书验证
                    try:
                        import urllib3
                        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
                    except Exception:
                        pass
                    
                    try:
                        response = requests.post(
                            api_url,
                            json=payload,
                            headers=headers,
                            timeout=timeout,
                            verify=False,  # 禁用 SSL 证书验证
                            proxies=proxies
                        )
                        response.raise_for_status()
                        obj = response.json()
                        
                        try:
                            content = obj['choices'][0]['message']['content']
                        except Exception:
                            content = None
                        
                        if content:
                            # 成功但需要警告用户
                            return {
                                'ok': True, 
                                'content': content, 
                                'error': None, 
                                'raw': obj,
                                'warning': '⚠️ 注意：由于 SSL 兼容性问题，本次请求禁用了证书验证（安全性降低）'
                            }
                    except Exception:
                        pass
                    
                    vendor = 'OpenAI' if provider == 'openai' else 'DeepSeek'
                    err_detail = (
                        f'{vendor} SSL 错误（证书或协议问题）\n\n'
                        f'可能原因：\n'
                        f'1. 系统缺少根证书或证书过期\n'
                        f'2. Python SSL 库版本过旧（需要 OpenSSL 1.1.1+）\n'
                        f'3. 网络代理干扰 HTTPS 连接\n\n'
                        f'建议：\n'
                        f'- 更新系统证书：pip install --upgrade certifi\n'
                        f'- 更新 requests：pip install --upgrade requests\n'
                        f'- 使用 Ollama 本地模型作为替代\n\n'
                        f'技术详情：{str(e)}'
                    )
                    return {'ok': False, 'content': None, 'error': err_detail, 'raw': None}
                    
                except requests.exceptions.HTTPError as e:
                    vendor = 'OpenAI' if provider == 'openai' else 'DeepSeek'
                    status_code = e.response.status_code if hasattr(e, 'response') else 'Unknown'
                    
                    try:
                        err_obj = e.response.json()
                        err_msg = (err_obj.get('error') or {}).get('message') or str(e)
                    except Exception:
                        err_obj = None
                        err_msg = str(e)
                    
                    if status_code == 401:
                        friendly = f'{vendor} 认证失败（401）。请检查 API Key 是否有效，或是否具有访问权限。'
                        return {'ok': False, 'content': None, 'error': f'{friendly}\n{err_msg}', 'raw': err_obj}
                    elif status_code == 429:
                        friendly = f'{vendor} 请求被限制或配额不足（429）。请检查套餐与账单，或稍后重试。'
                        return {'ok': False, 'content': None, 'error': f'{friendly}\n{err_msg}', 'raw': err_obj}
                    
                    # 检查是否是 400 错误且 URL 格式异常
                    if status_code == 400 and ('comv1' in api_url or 'com//' in api_url):
                        friendly = (
                            f'{vendor} API URL 格式异常（缺少斜杠）：{api_url}\n\n'
                            f'这通常是 Python 模块缓存问题导致的。请尝试：\n'
                            f'1. 关闭并重新打开 Houdini\n'
                            f'2. 或在 Python Shell 中执行：\n'
                            f'   import importlib\n'
                            f'   from HOUDINI_HIP_MANAGER.utils import ai_client\n'
                            f'   importlib.reload(ai_client)\n\n'
                            f'代码中定义的正确 URL: https://api.deepseek.com/v1/chat/completions'
                        )
                        return {'ok': False, 'content': None, 'error': friendly, 'raw': err_obj}
                    
                    return {'ok': False, 'content': None, 'error': f'HTTP {status_code}: {err_msg}', 'raw': err_obj}
                    
                except Exception as e:
                    vendor = 'OpenAI' if provider == 'openai' else 'DeepSeek'
                    error_str = str(e)
                    
                    # 检查错误信息中是否包含异常的 URL
                    if 'comv1' in error_str or 'com//' in error_str:
                        return {
                            'ok': False,
                            'content': None,
                            'error': (
                                f'{vendor} API URL 格式异常（模块缓存问题）\n\n'
                                f'请关闭并重新打开 Houdini，或使用 importlib.reload() 重新加载模块。\n\n'
                                f'错误详情：{error_str}'
                            ),
                            'raw': None
                        }
                    return {'ok': False, 'content': None, 'error': f'{vendor} 请求失败：{error_str}', 'raw': None}

        # 降级：使用 urllib（兼容性较差）
        data = json.dumps(payload).encode('utf-8')
        req = request.Request(api_url, data=data, headers=headers, method='POST')
        try:
            with request.urlopen(req, timeout=timeout, context=self._ssl_context) as resp:
                text = resp.read().decode('utf-8')
                obj = json.loads(text)
        except error.HTTPError as e:
            # 尽量解析服务端返回的错误体
            try:
                err_text = e.read().decode('utf-8')
                err_obj = json.loads(err_text)
                err_code = (err_obj.get('error') or {}).get('code')
                err_msg = (err_obj.get('error') or {}).get('message') or err_text
            except Exception:
                err_obj, err_code, err_msg = None, None, str(e)

            # 常见错误友好提示
            if e.code == 401:
                vendor = 'OpenAI' if provider == 'openai' else 'DeepSeek'
                friendly = f'{vendor} 认证失败（401）。请检查 API Key 是否有效，或是否具有访问权限。'
                return {'ok': False, 'content': None, 'error': f'{friendly}\n{err_msg}', 'raw': err_obj}
            if e.code == 429 or err_code == 'insufficient_quota':
                vendor = 'OpenAI' if provider == 'openai' else 'DeepSeek'
                friendly = f'{vendor} 请求被限制或配额不足（429/insufficient_quota）。请检查套餐与账单，或稍后重试。'
                return {'ok': False, 'content': None, 'error': f'{friendly}\n{err_msg}', 'raw': err_obj}

            return {'ok': False, 'content': None, 'error': f'HTTP {e.code}: {err_msg}', 'raw': err_obj}
        except Exception as e:
            vendor = 'OpenAI' if provider == 'openai' else 'DeepSeek'
            err_detail = str(e)
            
            # 针对常见 SSL/网络错误提供友好提示
            if 'EOF occurred in violation of protocol' in err_detail or 'ssl.c:' in err_detail:
                err_detail = (
                    f'{vendor} SSL 协议错误（通常由 Python SSL 版本过旧或不兼容导致）\n\n'
                    f'建议解决方案：\n'
                    f'1. 更新 Python SSL 库（如果使用 Houdini 内置 Python，这可能比较困难）\n'
                    f'2. 尝试使用系统 Python（而非 DCC 内置 Python）\n'
                    f'3. 检查 OpenSSL 版本：python -c "import ssl; print(ssl.OPENSSL_VERSION)"\n'
                    f'4. 如需临时解决，可考虑使用本地 Ollama 模型（无需网络调用）\n\n'
                    f'技术详情：{err_detail}'
                )
            elif 'No such file or directory' in err_detail:
                err_detail = f'{vendor} API 调用失败：URL 格式错误或网络配置问题。\n请检查：\n1) 网络连接是否正常\n2) 是否需要配置代理\n3) API URL: {api_url}\n原始错误: {err_detail}'
            elif 'timed out' in err_detail or 'timeout' in err_detail.lower():
                err_detail = f'{vendor} 连接超时。\n请检查：\n1) 网络连接\n2) 防火墙设置\n3) 是否需要代理\n原始错误: {err_detail}'
            
            return {'ok': False, 'content': None, 'error': err_detail, 'raw': None}

        try:
            content = obj['choices'][0]['message']['content']
        except Exception:
            content = None
        return {'ok': bool(content), 'content': content, 'error': None if content else '返回内容为空', 'raw': obj}
