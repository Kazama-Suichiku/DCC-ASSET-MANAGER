# -*- coding: utf-8 -*-
from __future__ import annotations

import re, time
from typing import Any, Optional

try:
	import hou  # type: ignore
except Exception:
	hou = None  # type: ignore

try:
	import requests
except Exception:
	requests = None  # type: ignore

from .settings import read_settings


class HoudiniMCP:
	"""Thin client for Houdini-side operations used by UI.

	This client mirrors the legacy utils.mcp.HoudiniMCP API so UI can migrate
	without touching server/tooling code.
	"""

	# -------- Selection & Search --------
	def describe_selection(self, limit: int = 3, include_all_params: bool = False) -> tuple[bool, str]:
		"""读取选中节点的信息
		
		Args:
			limit: 最多读取的节点数量
			include_all_params: 是否读取所有参数（包括默认值参数）
		"""
		if hou is None:
			return False, "当前未检测到 Houdini API（hou 模块）。请在 Houdini 中使用。"
		nodes = hou.selectedNodes()
		if not nodes:
			return False, "未选择任何节点。"
		lines: list[str] = []
		for node in nodes[:limit]:
			node_type = node.type()
			category = node_type.category().name() if node_type else "Unknown"
			type_name = node_type.name() if node_type else "unknown"
			info_lines = [
				f"=== 节点 {node.name()} ===",
				f"完整类型：{category.lower()}/{type_name}",
				f"节点描述：{node_type.description() if node_type else ''}",
				f"节点路径：{node.path()}",
				f"显示标记：{'是' if node.isDisplayFlagSet() else '否'}",
				f"渲染标记：{'是' if node.isRenderFlagSet() else '否'}",
			]
			comment = node.comment().strip()
			if comment:
				info_lines.append(f"用户备注：{comment}")
			
			# 读取节点的错误和警告信息
			has_issues = False
			try:
				errors = node.errors()
				if errors:
					has_issues = True
					info_lines.append("⚠️ 节点错误：")
					for err in errors:
						info_lines.append(f"  ❌ {err}")
			except Exception:
				pass
			
			# 检查节点烹饪状态
			try:
				if hasattr(node, 'isBypassed') and node.isBypassed():
					info_lines.append("🚫 节点状态：已旁路（Bypassed）")
					has_issues = True
				if hasattr(node, 'isLocked') and node.isLocked():
					info_lines.append("🔒 节点状态：已锁定（Locked）")
			except Exception:
				pass
			
			inputs = [i.path() if i else "(空)" for i in node.inputs()]
			outputs = [o.path() for o in node.outputs()]
			info_lines.append(f"输入连接：{', '.join(inputs) if inputs else '无'}")
			info_lines.append(f"输出连接：{', '.join(outputs) if outputs else '无'}")
			
			# 读取参数
			if include_all_params:
				all_params = self._collect_all_parameters(node)
				if all_params:
					info_lines.append("所有参数（键值对）：")
					info_lines.append(self._format_params_dict(all_params))
			else:
				key_params = self._collect_key_parameters(node, limit=8)
				if key_params:
					info_lines.append("非默认参数：")
					info_lines.extend([f"  {k} = {v}" for k, v in key_params])
			
			lines.append("\n".join(info_lines))
			lines.append("")
		if len(nodes) > limit:
			lines.append(f"（仅展示前 {limit} 个节点，共选择 {len(nodes)} 个）")
		if lines and not lines[-1].strip():
			lines.pop()
		return True, "\n".join(lines)

	def search_nodes(self, keyword: str, limit: int = 12) -> tuple[bool, str]:
		if hou is None:
			return False, "当前未检测到 Houdini API（hou 模块）。请在 Houdini 中使用。"
		if not keyword:
			return False, "请输入关键字。"
		kw = keyword.lower()
		matches: list[str] = []
		for cat_name, cat in hou.nodeTypeCategories().items():
			for type_name, node_type in cat.nodeTypes().items():
				lookup = f"{cat_name}/{type_name}"
				if kw in lookup.lower() or kw in node_type.description().lower():
					matches.append(f"- `{cat_name.lower()}/{type_name}` — {node_type.description()}")
		if not matches:
			return False, f"未找到包含 “{keyword}” 的节点类型。"
		if len(matches) > limit:
			extra = len(matches) - limit
			matches = matches[:limit] + [f"… 还有 {extra} 个结果，换个更精确的关键字试试。"]
		return True, "\n".join(matches)

	def search_documentation(self, node_type: str, category: str = "sop") -> tuple[bool, str]:
		if requests is None:
			return False, "requests 模块未安装。请先安装: pip install requests"
		base_url = "https://www.sidefx.com/docs/houdini/nodes"
		# 处理命名空间节点（如 labs::splatter -> labs--splatter）
		doc_node_type = node_type.replace("::", "--")
		doc_url = f"{base_url}/{category}/{doc_node_type}.html"
		settings = read_settings()
		tries = max(1, settings.request_retries + 1)
		last_err: Optional[Exception] = None
		response = None
		for _ in range(tries):
			try:
				response = requests.get(doc_url, timeout=settings.request_timeout)
				if response.status_code == 404:
					return False, f"未找到节点文档: {category}/{node_type}\n访问地址: {doc_url}"
				response.raise_for_status()
				break
			except Exception as e:
				last_err = e
				time.sleep(settings.request_backoff)
		if response is None:
			return False, f"文档查询失败（重试后仍失败）: {doc_url} | {last_err}"
		content = response.text
		title_match = re.search(r'<title>(.*?)</title>', content, re.IGNORECASE)
		title = title_match.group(1) if title_match else f"{node_type} node"
		summary = ""
		summary_match = re.search(r'<div[^>]*class="[^"]*summary[^"]*"[^>]*>(.*?)</div>', content, re.DOTALL | re.IGNORECASE)
		if summary_match:
			summary = re.sub(r'<[^>]+>', '', summary_match.group(1)).strip()
		params = ""
		params_match = re.search(r'<h2[^>]*>Parameters?</h2>(.*?)(?=<h2|$)', content, re.IGNORECASE | re.DOTALL)
		if params_match:
			params_html = params_match.group(1)
			param_items = re.findall(r'<dt[^>]*>(.*?)</dt>\s*<dd[^>]*>(.*?)</dd>', params_html, re.DOTALL | re.IGNORECASE)
			if param_items:
				lst = []
				for param_name, param_desc in param_items[:8]:
					clean_name = re.sub(r'<[^>]+>', '', param_name).strip()
					clean_desc = re.sub(r'<[^>]+>', '', param_desc).strip()
					if clean_name:
						lst.append(f"- **{clean_name}**: {clean_desc[:150]}")
				params = "\n".join(lst)
		result = f"## {title}\n\n"
		result += f"**文档链接**: {doc_url}\n\n"
		if summary:
			result += f"**节点描述**:\n{summary}\n\n"
		if params:
			result += f"**主要参数**:\n{params}\n"
		else:
			result += "详细参数信息请查看文档链接。\n"
		return True, result

	# -------- Create / Network --------
	def create_node(self, type_hint: str, node_name: str | None = None, parameters: dict[str, Any] | None = None) -> tuple[bool, str]:
		if hou is None:
			return False, "当前未检测到 Houdini API（hou 模块）。请在 Houdini 中使用。"
		network = self._current_network()
		if network is None:
			return False, "未找到网络编辑器或当前网络。"
		if not type_hint:
			return False, "未提供节点类型。"
		desired_cat = self._desired_category_from_hint(type_hint, network)
		if desired_cat is None:
			return False, f"无法识别节点类别：{type_hint}"
		network = self._ensure_target_network(network, desired_cat)
		resolved = self._resolve_node_type(type_hint, network)
		if resolved is None:
			return False, f"未识别的节点类型：{type_hint}"
		safe_name = self._sanitize_node_name(node_name)
		try:
			new_node = network.createNode(resolved, safe_name)
		except Exception as exc:
			return False, f"创建节点失败：{exc}"
		if parameters and isinstance(parameters, dict):
			for parm_name, parm_value in parameters.items():
				parm = new_node.parm(parm_name)
				if parm is None:
					continue
				try:
					parm.set(parm_value)
				except Exception:
					continue
		new_node.moveToGoodPosition()
		new_node.setSelected(True, clear_all_selected=True)
		try:
			editor = hou.ui.curDesktop().paneTabOfType(hou.paneTabType.NetworkEditor)
			if editor:
				editor.homeToSelection()
		except Exception:
			pass
		return True, f"节点已创建：`{new_node.path()}`"

	def create_network(self, plan: dict[str, Any]) -> tuple[bool, str]:
		if hou is None:
			return False, "当前未检测到 Houdini API（hou 模块）。请在 Houdini 中使用。"
		network = self._current_network()
		if network is None:
			return False, "未找到网络编辑器或当前网络。"
		node_specs = plan.get("nodes") if isinstance(plan, dict) else None
		if not node_specs:
			return False, "MCP 指令缺少 nodes 字段。"
		created: dict[str, Any] = {}
		creation_order: list[str] = []
		messages: list[str] = []
		try:
			try:
				current_category = network.childTypeCategory()
				current_cat_name = current_category.name().lower() if current_category else ""
			except Exception:
				current_category = None
				current_cat_name = ""
			has_obj_node = any((isinstance(spec, dict) and str(spec.get("type") or spec.get("node_type") or "").lower().startswith("obj/")) for spec in node_specs)
			has_sop_node = any((isinstance(spec, dict) and str(spec.get("type") or spec.get("node_type") or "").lower().startswith("sop/")) for spec in node_specs)
			if has_sop_node and not has_obj_node and current_cat_name.startswith("object"):
				try:
					auto_container = network.createNode("geo")
					auto_container.moveToGoodPosition()
					messages.append(f"未提供 OBJ 容器，已自动创建 `{auto_container.name()}` 以承载 SOP 节点。")
					network = auto_container
				except Exception as exc:
					messages.append(f"自动创建 SOP 容器失败：{exc}")
			for idx, spec in enumerate(node_specs):
				if not isinstance(spec, dict):
					messages.append(f"忽略第 {idx + 1} 个节点：不是有效的对象。")
					continue
				node_id = spec.get("id") or spec.get("name") or f"node_{idx+1}"
				type_hint = spec.get("type") or spec.get("node_type")
				if not type_hint:
					messages.append(f"[{node_id}] 缺少 type 字段，跳过。")
					continue
				desired_cat = self._desired_category_from_hint(type_hint, network)
				if desired_cat is None:
					messages.append(f"[{node_id}] 无法识别节点类别：{type_hint}")
					continue
				network = self._ensure_target_network(network, desired_cat)
				resolved_type = self._resolve_node_type(type_hint, network)
				if resolved_type is None:
					messages.append(f"[{node_id}] 未识别的节点类型：{type_hint}")
					continue
				node_name = spec.get("name")
				safe_name = self._sanitize_node_name(node_name)
				new_node = network.createNode(resolved_type, safe_name)
				# 支持 "parameters" 和 "parms" 两种写法
				params = spec.get("parameters") or spec.get("parms", {})
				if isinstance(params, dict):
					for parm_name, parm_value in params.items():
						parm = new_node.parm(parm_name)
						if parm is None:
							messages.append(f"[{node_id}] 未找到参数：{parm_name}")
							continue
						try:
							parm.set(parm_value)
						except Exception as exc:
							messages.append(f"[{node_id}] 参数 {parm_name} 设置失败：{exc}")
				created[node_id] = new_node
				creation_order.append(node_id)
			connections = plan.get("connections", []) if isinstance(plan, dict) else []
			for conn in connections:
				if not isinstance(conn, dict):
					continue
				src_id = conn.get("src") or conn.get("from")
				dst_id = conn.get("dst") or conn.get("to")
				input_index = conn.get("input")
				try:
					input_index = int(input_index if input_index is not None else conn.get("input_index", 0))
				except Exception:
					input_index = 0
				src_node = created.get(src_id)
				dst_node = created.get(dst_id)
				if not src_node or not dst_node:
					messages.append(f"连接失败：未找到 {src_id} 或 {dst_id}")
					continue
				try:
					dst_node.setInput(input_index, src_node)
				except Exception as exc:
					messages.append(f"连接 {src_id} -> {dst_id} 失败：{exc}")
			# 如果未给出 connections，则尝试根据常识自动连线
			if not connections:
				try:
					valid_order = [nid for nid in creation_order if nid in created]
					nodes_in_order = [created[nid] for nid in valid_order]
					# 顺序串联：若目标有可用输入且尚未连接，则将前一节点连到后一节点 input 0
					for i in range(1, len(nodes_in_order)):
						dst = nodes_in_order[i]
						src = nodes_in_order[i - 1]
						try:
							if dst.type().maxNumInputs() > 0 and not any(inp is not None for inp in dst.inputs()):
								dst.setInput(0, src)
						except Exception:
							pass
					# copytopoints 常识连接：0 口接几何，1 口接点/属性管线
					ctp_list = [n for n in nodes_in_order if n.type().name().lower() == "copytopoints"]
					if ctp_list:
						ctp = ctp_list[-1]
						geom = [n for n in nodes_in_order if n.type().name().lower() in ("box", "sphere", "tube", "grid", "merge", "file")] 
						pts = [n for n in nodes_in_order if n.type().name().lower() in ("scatter", "attribwrangle", "pointwrangle", "remesh")]
						if geom:
							try:
								ctp.setInput(0, geom[-1])
							except Exception:
								pass
						if pts and ctp.type().maxNumInputs() > 1:
							try:
								ctp.setInput(1, pts[-1])
							except Exception:
								pass
				except Exception:
					pass
			try:
				valid_order = [nid for nid in creation_order if nid in created]
				if valid_order:
					network.layoutChildren()
					last_node = created[valid_order[-1]]
					last_node.setSelected(True, clear_all_selected=True)
					try:
						last_node.setDisplayFlag(True)
						last_node.setRenderFlag(True)
					except Exception:
						pass
					try:
						editor = hou.ui.curDesktop().paneTabOfType(hou.paneTabType.NetworkEditor)
						if editor:
							editor.homeToSelection()
					except Exception:
						pass
			except Exception:
				pass
			summary = ", ".join(created[nid].path() for nid in creation_order if nid in created) if creation_order else "无"
			detail = "; ".join(messages) if messages else ""
			if created and messages:
				return True, f"已创建节点：{summary}。注意：{detail}"
			if created:
				return True, f"已创建节点：{summary}"
			return False, "未创建任何节点，请检查 MCP 指令。"
		except Exception as exc:
			return False, f"创建节点网络时发生异常：{exc}"

	def connect_nodes(self, output_node_path: str, input_node_path: str, input_index: int = 0) -> tuple[bool, str]:
		"""将输出节点连接到输入节点的指定输入口。

		参数：
		- output_node_path: 源（输出）节点路径
		- input_node_path: 目标（输入）节点路径
		- input_index: 连接到目标的第几个输入口（默认 0）
		"""
		if hou is None:
			return False, "当前未检测到 Houdini API（hou 模块）。请在 Houdini 中使用。"
		try:
			out_node = hou.node(output_node_path)
			if out_node is None:
				return False, f"输出节点不存在：{output_node_path}"
			in_node = hou.node(input_node_path)
			if in_node is None:
				return False, f"输入节点不存在：{input_node_path}"
			try:
				idx = int(input_index)
			except Exception:
				idx = 0
			max_inputs = in_node.type().maxNumInputs()
			if idx < 0 or idx >= max_inputs:
				return False, f"输入端口索引无效：{idx}（有效范围 0..{max_inputs-1}）"
			in_node.setInput(idx, out_node, 0)
			return True, f"已连接：{output_node_path} -> {input_node_path}[{idx}]"
		except Exception as exc:
			return False, f"连接失败：{exc}"

	# -------- Set Parameters --------
	def set_parameter(self, node_path: str, param_name: str, value: any) -> tuple[bool, str]:
		"""设置节点参数值。

		参数：
		- node_path: 节点路径
		- param_name: 参数名称
		- value: 参数值（支持字符串、数字、列表等）
		"""
		if hou is None:
			return False, "当前未检测到 Houdini API（hou 模块）。请在 Houdini 中使用。"
		try:
			node = hou.node(node_path)
			if node is None:
				return False, f"未找到节点：{node_path}"
			
			# 尝试获取参数
			parm = node.parm(param_name)
			if parm is None:
				# 尝试作为元组参数
				parm_tuple = node.parmTuple(param_name)
				if parm_tuple is None:
					return False, f"节点 {node_path} 中未找到参数 '{param_name}'"
				# 设置元组参数
				if isinstance(value, (list, tuple)):
					parm_tuple.set(value)
					return True, f"已设置参数 {param_name} = {value}"
				else:
					return False, f"参数 '{param_name}' 是元组参数，需要提供列表或元组值"
			
			# 设置单个参数
			parm.set(value)
			actual_value = parm.eval()
			return True, f"已设置参数 {param_name} = {actual_value}"
		except Exception as exc:
			return False, f"设置参数失败：{exc}"

	# -------- Delete Ops --------
	def delete_node_by_path(self, node_path: str) -> tuple[bool, str]:
		if hou is None:
			return False, "当前未检测到 Houdini API（hou 模块）。请在 Houdini 中使用。"
		try:
			node = hou.node(node_path)
			if node is None:
				return False, f"未找到节点：{node_path}"
			name = node.name()
			node.destroy()
			return True, f"已删除节点 {name}（{node_path}）"
		except Exception as exc:
			return False, f"删除失败：{exc}"

	def delete_selected(self) -> tuple[bool, str]:
		if hou is None:
			return False, "当前未检测到 Houdini API（hou 模块）。请在 Houdini 中使用。"
		try:
			nodes = list(hou.selectedNodes())
			if not nodes:
				return False, "没有选中的节点。"
			paths = [n.path() for n in nodes]
			for n in nodes:
				try:
					n.destroy()
				except Exception:
					pass
			return True, "已删除 {} 个节点：\n- ".format(len(paths)) + "\n- ".join(paths)
		except Exception as exc:
			return False, f"删除失败：{exc}"

	def delete_nodes_by_paths(self, node_paths: list[str]) -> tuple[bool, str]:
		"""批量按路径删除节点。"""
		if hou is None:
			return False, "当前未检测到 Houdini API（hou 模块）。请在 Houdini 中使用。"
		if not node_paths:
			return False, "没有提供任何节点路径。"
		ok_paths: list[str] = []
		skipped: list[str] = []
		for p in node_paths:
			try:
				n = hou.node(str(p))
				if n is None:
					skipped.append(str(p))
					continue
				ok_paths.append(n.path())
				n.destroy()
			except Exception:
				skipped.append(str(p))
		msg = f"已删除 {len(ok_paths)} 个节点。"
		if skipped:
			msg += " 跳过：" + ", ".join(skipped)
		return (len(ok_paths) > 0), msg

	def delete_nodes_by_names(self, names: list[str], parent_path: str | None = None) -> tuple[bool, str]:
		"""按名称在指定父节点（或当前网络）下批量删除。"""
		if hou is None:
			return False, "当前未检测到 Houdini API（hou 模块）。请在 Houdini 中使用。"
		if not names:
			return False, "没有提供任何节点名称。"
		parent = hou.node(parent_path) if parent_path else self._current_network()
		if parent is None:
			return False, "未找到网络上下文，请打开网络编辑器。"
		ok_paths: list[str] = []
		skipped: list[str] = []
		name_set = {str(n) for n in names}
		for ch in parent.children():
			try:
				if ch.name() in name_set:
					ok_paths.append(ch.path())
					ch.destroy()
			except Exception:
				skipped.append(ch.name())
		msg = f"已删除 {len(ok_paths)} 个节点。"
		if skipped:
			msg += " 跳过：" + ", ".join(skipped)
		return (len(ok_paths) > 0), msg

	def delete_all_children(self, parent_path: str | None = None) -> tuple[bool, str]:
		"""删除指定父节点（或当前网络）的所有子节点。"""
		if hou is None:
			return False, "当前未检测到 Houdini API（hou 模块）。请在 Houdini 中使用。"
		parent = hou.node(parent_path) if parent_path else self._current_network()
		if parent is None:
			return False, "未找到网络上下文，请打开网络编辑器。"
		children = list(parent.children())
		if not children:
			return True, "没有可删除的子节点。"
		ok_paths: list[str] = []
		errs: list[str] = []
		for ch in children:
			try:
				ok_paths.append(ch.path())
				ch.destroy()
			except Exception as e:
				errs.append(f"{ch.path()}: {e}")
		msg = f"已删除 {len(ok_paths)} 个子节点。"
		if errs:
			msg += " 存在错误：" + "; ".join(errs)
		return (len(ok_paths) > 0 and not errs), msg

	# -------- internals --------
	def _collect_key_parameters(self, node: Any, limit: int = 6) -> list[tuple[str, str]]:
		"""收集非默认参数（用于简化显示）"""
		pairs: list[tuple[str, str]] = []
		for parm in node.parms():
			try:
				if parm.isHidden() or parm.isDisabled():
					continue
			except Exception:
				continue
			try:
				if parm.parmTemplate().type().name() not in {"Int", "Float", "Toggle", "Menu", "String"}:
					continue
			except Exception:
				continue
			try:
				value = parm.eval()
			except Exception:
				continue
			if isinstance(value, float):
				try:
					value = round(value, 4)
				except Exception:
					pass
			try:
				if hasattr(parm, "isAtDefault") and parm.isAtDefault():
					continue
			except Exception:
				pass
			pairs.append((parm.name(), str(value)))
			if len(pairs) >= limit:
				break
		return pairs

	def _collect_all_parameters(self, node: Any) -> dict[str, Any]:
		"""收集节点的所有参数（包括默认值参数）"""
		params_dict = {}
		for parm in node.parms():
			try:
				# 跳过隐藏和禁用的参数
				if parm.isHidden() or parm.isDisabled():
					continue
			except Exception:
				continue
			
			try:
				parm_name = parm.name()
				value = parm.eval()
				
				# 格式化浮点数
				if isinstance(value, float):
					value = round(value, 6)
				
				params_dict[parm_name] = value
			except Exception:
				continue
		
		return params_dict

	def _format_params_dict(self, params: dict[str, Any]) -> str:
		"""将参数字典格式化为易读的字符串"""
		if not params:
			return "  {}"
		
		# 按参数名排序
		sorted_params = sorted(params.items())
		
		# 如果参数数量较少（<=5），使用紧凑格式
		if len(sorted_params) <= 5:
			items = []
			for key, value in sorted_params:
				if isinstance(value, str):
					items.append(f'"{key}": "{value}"')
				else:
					items.append(f'"{key}": {value}')
			return "  { " + ", ".join(items) + " }"
		
		# 参数较多时使用多行格式
		lines = ["  {"]
		for key, value in sorted_params:
			# 字符串值用引号包裹
			if isinstance(value, str):
				formatted_value = f'"{value}"'
			else:
				formatted_value = str(value)
			lines.append(f'    "{key}": {formatted_value},')
		lines.append("  }")
		
		return "\n".join(lines)

	def _current_network(self) -> Any:
		try:
			editor = hou.ui.curDesktop().paneTabOfType(hou.paneTabType.NetworkEditor)
			return editor.pwd() if editor else None
		except Exception:
			return None

	def _resolve_node_type(self, type_hint: str, network: Any) -> str | None:
		hint = (type_hint or '').strip()
		if not hint:
			return None
		if "/" in hint:
			prefix, node_name = hint.split("/", 1)
			category = self._category_from_hint(prefix) or (network.childTypeCategory() if network else None)
		else:
			node_name = hint
			category = network.childTypeCategory() if network else None
		if not category:
			return None
		node_types = category.nodeTypes()
		if node_name in node_types:
			return node_name
		lowered = node_name.lower()
		for candidate in node_types:
			if candidate.lower() == lowered:
				return candidate
		alias_map = {
			"copy": ["copytopoints", "copyandtransform"],
			"group": ["groupexpression", "groupcreate"],
			"polyextrude": ["polyextrude"],
		}
		if lowered in alias_map:
			for alt in alias_map[lowered]:
				if alt in node_types:
					return alt
				for candidate in node_types:
					if candidate.lower() == alt.lower():
						return candidate
		partial_candidates = [c for c in node_types if lowered in c.lower()]
		if partial_candidates:
			preferred = ["copytopoints", "attribwrangle", "scatter", "box", "sphere", "null"]
			for pref in preferred:
				for c in partial_candidates:
					if c.lower() == pref:
						return c
			return partial_candidates[0]
		return None

	def _category_from_hint(self, prefix: str) -> Any:
		try:
			prefix_lower = (prefix or '').strip().lower()
			for name, category in hou.nodeTypeCategories().items():
				if name.lower() == prefix_lower:
					return category
		except Exception:
			return None
		return None

	def _desired_category_from_hint(self, type_hint: str, network: Any) -> Any:
		try:
			if "/" in (type_hint or ''):
				prefix = type_hint.split("/", 1)[0]
				return self._category_from_hint(prefix) or (network.childTypeCategory() if network else None)
			return network.childTypeCategory() if network else None
		except Exception:
			return None

	def _ensure_target_network(self, network: Any, desired_category: Any) -> Any:
		try:
			current_cat = network.childTypeCategory() if network else None
			if current_cat == desired_category:
				return network
			current_name = (current_cat.name().lower() if current_cat else "")
			desired_name = (desired_category.name().lower() if desired_category else "")
			if current_name == desired_name:
				return network
			if current_name.startswith("object") and desired_name.startswith("sop"):
				try:
					container = network.createNode("geo")
					container.moveToGoodPosition()
					return container
				except Exception:
					return network
			if desired_name.startswith("sop") and not current_name.startswith("sop"):
				try:
					obj_root = hou.node("/obj") if hou is not None else None
					if obj_root is not None:
						for cand in ["mcp_auto", "mcp_auto_geo", "mcp_geo"]:
							existing = obj_root.node(cand)
							if existing is not None:
								return existing
						container = obj_root.createNode("geo", node_name="mcp_auto")
						container.moveToGoodPosition()
						return container
				except Exception:
					return network
		except Exception:
			return network
		return network

	def _sanitize_node_name(self, name: str | None) -> str | None:
		try:
			if not name:
				return None
			cleaned = str(name).strip()
			if not cleaned:
				return None
			cleaned = re.sub(r"[^A-Za-z0-9_]+", "_", cleaned)
			cleaned = cleaned.strip("_") or None
			return cleaned
		except Exception:
			return None
