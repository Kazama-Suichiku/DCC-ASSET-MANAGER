# -*- coding: utf-8 -*-
"""Houdini MCP package.

Public APIs:
- HoudiniMCP: UI-side helper client
- ensure_mcp_running / stop_mcp_server / get_mcp_status: server lifecycle
- MCPSettings / read_settings / get_logger: config and logging
"""
from __future__ import annotations

from .settings import MCPSettings, read_settings
from .logger import get_logger
from .client import HoudiniMCP
from .server import ensure_mcp_running, stop_mcp_server, get_mcp_status

__all__ = [
    "MCPSettings",
    "read_settings",
    "get_logger",
    "HoudiniMCP",
    "ensure_mcp_running",
    "stop_mcp_server",
    "get_mcp_status",
]
