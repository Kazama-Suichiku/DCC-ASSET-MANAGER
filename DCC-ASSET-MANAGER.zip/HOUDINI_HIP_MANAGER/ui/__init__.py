"""Houdini HIP Manager - UI Module"""
