"""Houdini HIP Manager - Core Module"""
