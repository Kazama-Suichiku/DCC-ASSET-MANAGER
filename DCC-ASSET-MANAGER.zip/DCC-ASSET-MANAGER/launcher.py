"""
DCC Asset Manager - 统一启动器
支持 Houdini 和 Maya 的资产管理工具
"""

import sys
import os

def detect_dcc():
    """检测当前运行的 DCC 软件"""
    try:
        import hou
        return "houdini"
    except ImportError:
        pass
    
    try:
        import maya.cmds as cmds
        return "maya"
    except ImportError:
        pass
    
    return None

def launch_houdini_manager():
    """启动 Houdini HIP Manager"""
    tool_path = os.path.join(os.path.dirname(__file__), "HOUDINI_HIP_MANAGER")
    if tool_path not in sys.path:
        sys.path.insert(0, tool_path)
    
    try:
        # 重新加载以支持热更新
        if 'main' in sys.modules:
            import importlib
            import main
            importlib.reload(main)
        else:
            import main
        
        return main.show_tool()
    except Exception as e:
        print(f"启动 Houdini HIP Manager 失败: {e}")
        import traceback
        traceback.print_exc()
        return None

def launch_maya_manager():
    """启动 Maya Asset Manager"""
    tool_path = os.path.join(os.path.dirname(__file__), "MAYA_MANAGER")
    if tool_path not in sys.path:
        sys.path.insert(0, tool_path)
    
    try:
        # 重新加载以支持热更新
        if 'maya_main' in sys.modules:
            import importlib
            import maya_main
            importlib.reload(maya_main)
        else:
            import maya_main
        
        return maya_main.show_tool()
    except Exception as e:
        print(f"启动 Maya Asset Manager 失败: {e}")
        import traceback
        traceback.print_exc()
        return None

def launch():
    """自动检测并启动对应的管理器"""
    dcc = detect_dcc()
    
    if dcc == "houdini":
        print("检测到 Houdini 环境，启动 HIP Manager...")
        return launch_houdini_manager()
    elif dcc == "maya":
        print("检测到 Maya 环境，启动 Maya Asset Manager...")
        return launch_maya_manager()
    else:
        print("错误：未检测到支持的 DCC 软件（Houdini 或 Maya）")
        print("请在 Houdini 或 Maya 中运行此工具。")
        return None

# 全局变量存储窗口实例
_manager_window = None

def show_tool():
    """统一入口函数"""
    global _manager_window
    _manager_window = launch()
    return _manager_window

if __name__ == "__main__":
    show_tool()
