# -*- coding: utf-8 -*-
"""
Asset Check Tab
资产检查标签页（改为内置配置 UI，不再依赖 CSV）
"""

import os
from PySide6 import QtWidgets, QtCore
from ..core.asset_checker import MayaAssetChecker


class AssetCheckTab(QtWidgets.QWidget):
    """资产检查Tab"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.checker = MayaAssetChecker()
        self._init_ui()
        self._load_existing_config_into_ui()
        
    def _init_ui(self):
        """初始化UI"""
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # 配置区域（内置表单）
        config_group = QtWidgets.QGroupBox("检查配置（保存在项目 config 目录）")
        config_v = QtWidgets.QVBoxLayout(config_group)

        # 是否检查单位
        self.cb_unit_check = QtWidgets.QCheckBox("启用单位检查（应为米 m）")
        self.cb_unit_check.setChecked(True)
        unit_row = QtWidgets.QHBoxLayout()
        unit_row.addWidget(self.cb_unit_check)
        unit_row.addStretch(1)
        self.btn_set_unit_m = QtWidgets.QPushButton("一键改为米 (m)")
        unit_row.addWidget(self.btn_set_unit_m)
        config_v.addLayout(unit_row)

        # 检查项表格
        table_layout = QtWidgets.QVBoxLayout()
        # 重命名前缀/后缀配置与应用
        rename_grid = QtWidgets.QGridLayout()
        rename_grid.setHorizontalSpacing(8)
        rename_grid.setVerticalSpacing(6)
        # 前缀
        rename_grid.addWidget(QtWidgets.QLabel("重命名前缀："), 0, 0)
        self.prefix_edit = QtWidgets.QLineEdit()
        self.prefix_edit.setPlaceholderText("例如：LOD0_ / COL_ / SM_")
        rename_grid.addWidget(self.prefix_edit, 0, 1)
        self.btn_apply_prefix = QtWidgets.QPushButton("将前缀应用到当前选择")
        rename_grid.addWidget(self.btn_apply_prefix, 0, 2)
        # 后缀
        rename_grid.addWidget(QtWidgets.QLabel("重命名后缀："), 1, 0)
        self.suffix_edit = QtWidgets.QLineEdit()
        self.suffix_edit.setPlaceholderText("例如：_HP / _LOD0 / _COL")
        rename_grid.addWidget(self.suffix_edit, 1, 1)
        self.btn_apply_suffix = QtWidgets.QPushButton("将后缀应用到当前选择")
        rename_grid.addWidget(self.btn_apply_suffix, 1, 2)
        table_layout.addLayout(rename_grid)

        self.table = QtWidgets.QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["check_type", "limit", "target"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.DoubleClicked | QtWidgets.QAbstractItemView.SelectedClicked)
        table_layout.addWidget(self.table)

        buttons_h = QtWidgets.QHBoxLayout()
        self.btn_add = QtWidgets.QPushButton("新增检查")
        self.btn_remove = QtWidgets.QPushButton("删除选中")
        self.btn_save_cfg = QtWidgets.QPushButton("保存配置")
        self.btn_help = QtWidgets.QPushButton("帮助")
        buttons_h.addWidget(self.btn_add)
        buttons_h.addWidget(self.btn_remove)
        buttons_h.addStretch(1)
        buttons_h.addWidget(self.btn_help)
        buttons_h.addWidget(self.btn_save_cfg)
        table_layout.addLayout(buttons_h)

        config_v.addLayout(table_layout)
        layout.addWidget(config_group)
        
        # 操作按钮区域
        button_layout = QtWidgets.QHBoxLayout()
        
        self.run_check_btn = QtWidgets.QPushButton("运行检查")
        self.run_check_btn.setMinimumHeight(40)
        self.run_check_btn.setStyleSheet("QPushButton { background-color: #2d5a2d; color: white; font-weight: bold; }")
        self.run_check_btn.clicked.connect(self._run_check)
        self.btn_add.clicked.connect(self._on_add_row)
        self.btn_remove.clicked.connect(self._on_remove_rows)
        self.btn_save_cfg.clicked.connect(self._on_save_config)
        self.btn_set_unit_m.clicked.connect(self._on_set_unit_meters)
        self.btn_help.clicked.connect(self._on_help)
        self.btn_apply_suffix.clicked.connect(self._on_apply_suffix)
        self.btn_apply_prefix.clicked.connect(self._on_apply_prefix)
        button_layout.addWidget(self.run_check_btn)
        
        clear_btn = QtWidgets.QPushButton("清空输出")
        clear_btn.setMinimumHeight(40)
        clear_btn.setStyleSheet("QPushButton { background-color: #5a2d2d; color: white; font-weight: bold; }")
        clear_btn.clicked.connect(self._clear_output)
        button_layout.addWidget(clear_btn)
        
        refresh_btn = QtWidgets.QPushButton("刷新状态")
        refresh_btn.setMinimumHeight(40)
        refresh_btn.clicked.connect(self._refresh_status)
        button_layout.addWidget(refresh_btn)
        
        layout.addLayout(button_layout)
        
        # 输出区域
        output_group = QtWidgets.QGroupBox("检查结果")
        output_layout = QtWidgets.QVBoxLayout(output_group)
        
        self.output_text = QtWidgets.QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setPlaceholderText("点击'运行检查'开始检查...")
        output_layout.addWidget(self.output_text)
        
        layout.addWidget(output_group, 1)

    # 简单的帮助对话框
    class _ConfigHelpDialog(QtWidgets.QDialog):
        def __init__(self, parent=None):
            super().__init__(parent)
            self.setWindowTitle("检查配置说明")
            self.resize(560, 420)
            v = QtWidgets.QVBoxLayout(self)
            text = QtWidgets.QTextEdit()
            text.setReadOnly(True)
            text.setHtml(
                """
                <h3>检查配置使用说明</h3>
                <p>配置会保存到仓库根目录下的 <code>config/maya_asset_check.ini</code>。</p>
                <p>勾选“启用单位检查”可在运行检查时验证 Maya 线性单位是否为 <b>米(m)</b>。</p>
                <p>下表用于添加其它检查项，字段含义：</p>
                <ul>
                  <li><b>check_type</b>：检查类型（目前支持 <code>uv_sets</code>、<code>poly_faces</code>）</li>
                  <li><b>limit</b>：阈值/上限，例如 <code>uv_sets</code> 期望数量、<code>poly_faces</code> 面数上限</li>
                  <li><b>target</b>：目标限定（可选），例如 <code>poly_faces</code> 可填写一个后缀来限定匹配的 Transform 名称</li>
                </ul>
                <p>示例：</p>
                <pre>
check_type: uv_sets,  limit: 1,   target:   
check_type: poly_faces, limit: 5000, target: _HP   (仅检查名字以 _HP 结尾的对象)
                </pre>
                <p>保存配置后，检查项会以 JSON 文本形式写入 <code>checks</code> 字段。</p>
                <hr/>
                <p>快速设置单位：点击“<b>一键改为米 (m)</b>”将 Maya 的线性单位调整为米。</p>
                """
            )
            v.addWidget(text)
            btn = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok)
            btn.accepted.connect(self.accept)
            v.addWidget(btn)

    def _on_help(self):
        dlg = self._ConfigHelpDialog(self)
        dlg.exec()

    def _on_set_unit_meters(self):
        """将 Maya 单位设置为米(m)"""
        try:
            ok, prev = self.checker.set_units_to_meters()
            if ok:
                QtWidgets.QMessageBox.information(self, "完成", f"已将单位设置为 米(m)。原单位：{prev}")
            else:
                QtWidgets.QMessageBox.warning(self, "提示", "未能设置单位（可能不在 Maya 环境或无权限）")
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "错误", f"设置单位失败：\n{e}")

    def _on_apply_suffix(self):
        suffix = self.suffix_edit.text().strip()
        if not suffix:
            QtWidgets.QMessageBox.information(self, "提示", "请先填写重命名后缀，例如：_HP / _LOD0 / _COL")
            return
        # 更新 checker 的配置中的后缀，便于保存
        self.checker.rename_suffix = suffix
        try:
            result = self.checker.add_suffix_to_selected(suffix)
            renamed = result.get("renamed", [])
            skipped = result.get("skipped", [])
            lines = ["重命名结果："]
            if renamed:
                lines.append("\n成功：")
                for old, new in renamed:
                    lines.append(f"  {old} -> {new}")
            if skipped:
                lines.append("\n跳过：")
                for name in skipped:
                    lines.append(f"  {name}")
            self.output_text.append("\n" + "\n".join(lines) + "\n")
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "错误", f"批量重命名失败：\n{e}")

    def _on_apply_prefix(self):
        prefix = self.prefix_edit.text().strip()
        if not prefix:
            QtWidgets.QMessageBox.information(self, "提示", "请先填写重命名前缀，例如：LOD0_ / COL_ / SM_")
            return
        self.checker.rename_prefix = prefix
        try:
            result = self.checker.add_prefix_to_selected(prefix)
            renamed = result.get("renamed", [])
            skipped = result.get("skipped", [])
            lines = ["重命名结果："]
            if renamed:
                lines.append("\n成功：")
                for old, new in renamed:
                    lines.append(f"  {old} -> {new}")
            if skipped:
                lines.append("\n跳过：")
                for name in skipped:
                    lines.append(f"  {name}")
            self.output_text.append("\n" + "\n".join(lines) + "\n")
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "错误", f"批量重命名失败：\n{e}")
        
    def _collect_checks_from_ui(self):
        checks = []
        for row in range(self.table.rowCount()):
            def _get(col):
                item = self.table.item(row, col)
                return item.text().strip() if item else ""
            typ = _get(0)
            limit = _get(1)
            target = _get(2)
            if not typ:
                continue
            try:
                limit_val = int(limit) if limit else 0
            except Exception:
                limit_val = 0
            checks.append({
                'check_type': typ,
                'limit': limit_val,
                'target': target
            })
        return checks
    
    def _run_check(self):
        """运行检查"""
        # 运行检查
        try:
            self.output_text.clear()
            self.output_text.append("正在运行检查...\n")
            QtWidgets.QApplication.processEvents()

            # 同步 UI 到检查器
            checks = self._collect_checks_from_ui()
            self.checker.enable_unit_check = self.cb_unit_check.isChecked()
            self.checker.checks = checks

            results = self.checker.run_all_checks()
            self.output_text.clear()
            self.output_text.append("\n".join(results))
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "错误", f"检查过程中发生错误:\n{e}")
    
    def _clear_output(self):
        """清空输出"""
        self.output_text.clear()
        self.output_text.setPlaceholderText("点击'运行检查'开始检查...")
    
    def _refresh_status(self):
        """刷新状态"""
        self.output_text.clear()
        self.output_text.append("状态已刷新\n")
        
        try:
            # 显示当前选择的对象信息
            from ..core.asset_checker import MayaAssetChecker
            checker = MayaAssetChecker()
            info = checker.get_selection_info()
            
            self.output_text.append(f"当前选择: {info['count']} 个对象\n")
            
            if info['count'] > 0:
                self.output_text.append("对象详情:")
                for detail in info['details']:
                    self.output_text.append(f"\n  • {detail['name']}")
                    self.output_text.append(f"    类型: {detail['type']}")
                    self.output_text.append(f"    枢轴: {detail['pivot']}")
                    if detail['face_count'] > 0:
                        self.output_text.append(f"    面数: {detail['face_count']}")
        except:
            self.output_text.append("无法获取Maya选择信息")

    def _on_add_row(self):
        row = self.table.rowCount()
        self.table.insertRow(row)
        # 默认一条 uv_sets 限制 1 的检查
        self.table.setItem(row, 0, QtWidgets.QTableWidgetItem("uv_sets"))
        self.table.setItem(row, 1, QtWidgets.QTableWidgetItem("1"))
        self.table.setItem(row, 2, QtWidgets.QTableWidgetItem(""))

    def _on_remove_rows(self):
        rows = sorted({idx.row() for idx in self.table.selectedIndexes()}, reverse=True)
        for r in rows:
            self.table.removeRow(r)

    def _on_save_config(self):
        checks = self._collect_checks_from_ui()
        # 同步保存重命名后缀配置
        suffix = self.suffix_edit.text().strip()
        prefix = self.prefix_edit.text().strip()
        if suffix:
            self.checker.rename_suffix = suffix
        if prefix:
            self.checker.rename_prefix = prefix
        ok, path = self.checker.save_config(
            self.cb_unit_check.isChecked(),
            checks,
            rename_suffix=self.checker.rename_suffix,
            rename_prefix=self.checker.rename_prefix,
        )
        if ok:
            QtWidgets.QMessageBox.information(self, "成功", f"配置已保存：\n{path}")
        else:
            QtWidgets.QMessageBox.critical(self, "失败", "配置保存失败，请检查控制台日志。")

    def _load_existing_config_into_ui(self):
        # 初始化 UI 为当前检查器配置
        try:
            self.cb_unit_check.setChecked(bool(self.checker.enable_unit_check))
            # 重命名后缀
            try:
                self.suffix_edit.setText(self.checker.rename_suffix or "")
            except Exception:
                pass
            # 重命名前缀
            try:
                self.prefix_edit.setText(self.checker.rename_prefix or "")
            except Exception:
                pass
            self.table.setRowCount(0)
            for chk in (self.checker.checks or []):
                row = self.table.rowCount()
                self.table.insertRow(row)
                self.table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(chk.get('check_type') or chk.get('type') or "")))
                self.table.setItem(row, 1, QtWidgets.QTableWidgetItem(str(chk.get('limit') or 0)))
                self.table.setItem(row, 2, QtWidgets.QTableWidgetItem(str(chk.get('target') or "")))
        except Exception:
            pass
