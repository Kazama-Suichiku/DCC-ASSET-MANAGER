# -*- coding: utf-8 -*-
"""
Maya Manager Main Window
Maya 管理器主窗口 - PySide6版本
"""

import os
from PySide6 import QtWidgets, QtCore, QtGui


class MayaManagerWindow(QtWidgets.QMainWindow):
    """Maya Asset Manager 主窗口"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Suichiku 的 Maya 工具箱")
        self.resize(800, 650)
        # 始终置顶
        try:
            self.setWindowFlag(QtCore.Qt.WindowStaysOnTopHint, True)
        except Exception:
            # 旧版本 Qt 兼容处理
            self.setWindowFlags(self.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
        
        # 初始化组件
        self._init_ui()
        
    def _init_ui(self):
        """初始化UI"""
        # 创建中心部件
        central_widget = QtWidgets.QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QtWidgets.QVBoxLayout(central_widget)
        
        # 创建Tab控件
        self.tab_widget = QtWidgets.QTabWidget()
        main_layout.addWidget(self.tab_widget)
        
        # 导入必要的Tab
        from .asset_check_tab import AssetCheckTab
        from .export_tab import ExportTab
        
        # 添加资产检查Tab
        self.asset_check_tab = AssetCheckTab()
        self.tab_widget.addTab(self.asset_check_tab, "资产检查")
        
        # 添加模型导出Tab
        self.export_tab = ExportTab()
        self.tab_widget.addTab(self.export_tab, "模型导出")
        
        # 状态栏
        self.statusBar().showMessage("就绪")

        # 工具栏：打开 P4V（高亮按钮）
        toolbar = self.addToolBar("工具")
        toolbar.setMovable(False)
        btn_p4v = QtWidgets.QToolButton(self)
        btn_p4v.setText("打开 P4V")
        btn_p4v.setToolTip("启动 Perforce P4V 客户端")
        try:
            btn_p4v.setCursor(QtCore.Qt.PointingHandCursor)
        except Exception:
            pass
        # 显眼的配色（橙色系），同时兼容禁用态
        btn_p4v.setStyleSheet(
            "QToolButton { background-color: #FF9800; color: #FFFFFF; font-weight: bold;"
            " padding: 6px 10px; border-radius: 4px; }"
            "QToolButton:hover { background-color: #FB8C00; }"
            "QToolButton:pressed { background-color: #F57C00; }"
            "QToolButton:disabled { background-color: #BDBDBD; color: #EEEEEE; }"
        )
        btn_p4v.clicked.connect(self._on_open_p4v)
        toolbar.addWidget(btn_p4v)

    def _on_open_p4v(self):
        try:
            from shared.p4v_utils import launch_p4v
            res = launch_p4v(self)
            if res == "already_running":
                self.statusBar().showMessage("P4V 已在运行", 3000)
            elif res is True:
                self.statusBar().showMessage("已启动 P4V", 3000)
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "提示", f"无法启动 P4V：\n{e}")
        
    def show_message(self, title, message, icon=QtWidgets.QMessageBox.Information):
        """显示消息对话框"""
        msg_box = QtWidgets.QMessageBox(self)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.setIcon(icon)
        msg_box.exec()
