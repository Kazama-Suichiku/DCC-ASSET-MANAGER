# -*- coding: utf-8 -*-
"""
Maya Asset Checker
Maya 资产检查器（不再使用 CSV，改为统一 config 目录的 JSON 配置）
"""

import json
from typing import List, Dict, Any, Optional
from shared.common_utils import load_config, save_config

class MayaAssetChecker:
    """Maya 资产检查器"""
    
    def __init__(self):
        cfg = self._load_config()
        self.enable_unit_check = bool(cfg.get('enable_unit_check', True))
        self.checks: List[Dict[str, Any]] = cfg.get('checks', [])
        self.rename_suffix: str = cfg.get('rename_suffix', '') or ''
        self.rename_prefix: str = cfg.get('rename_prefix', '') or ''
        self.results = []
        
    def detect_maya(self):
        """检测是否在Maya环境中"""
        try:
            from importlib import import_module
            import_module('maya.cmds')
            return True
        except Exception:
            return False

    def _load_config(self) -> Dict[str, Any]:
        """从统一 config 目录加载 Maya 检查配置"""
        cfg, _ = load_config('asset_check', dcc_type='maya')
        data = {}
        if not cfg:
            # 默认配置
            data = {
                'enable_unit_check': True,
                'checks': [],
                'rename_suffix': '',
                'rename_prefix': ''
            }
        else:
            try:
                data['enable_unit_check'] = cfg.get('enable_unit_check', 'True') in (True, 'True', '1', 'true', 'YES', 'yes')
                # checks 采用 JSON 存储
                checks_json = cfg.get('checks', '[]')
                data['checks'] = json.loads(checks_json) if isinstance(checks_json, str) else (checks_json or [])
                data['rename_suffix'] = cfg.get('rename_suffix', '') or ''
                data['rename_prefix'] = cfg.get('rename_prefix', '') or ''
            except Exception:
                data = {
                    'enable_unit_check': True,
                    'checks': [],
                    'rename_suffix': '',
                    'rename_prefix': ''
                }
        return data

    def save_config(self, enable_unit_check: bool, checks: List[Dict[str, Any]], rename_suffix: Optional[str] = None, rename_prefix: Optional[str] = None):
        """保存 Maya 检查配置到统一 config 目录"""
        try:
            if rename_suffix is None:
                rename_suffix = self.rename_suffix
            if rename_prefix is None:
                rename_prefix = self.rename_prefix
            cfg = {
                'enable_unit_check': 'True' if enable_unit_check else 'False',
                'checks': json.dumps(checks, ensure_ascii=False),
                'rename_suffix': rename_suffix or '',
                'rename_prefix': rename_prefix or ''
            }
            ok, path = save_config('asset_check', cfg, dcc_type='maya')
            return ok, path
        except Exception as e:
            print(f"保存配置失败: {e}")
            return False, ""

    def add_suffix_to_selected(self, suffix: Optional[str] = None) -> dict:
        """为当前选择的 Transform 对象批量追加后缀。

        规则：
        - 仅处理 transform（会从 shape/组件选择回溯到 transform）。
        - 已有相同后缀的不会重复添加。
        - 如发生重名，自动在末尾加 _001, _002 保证唯一。

        返回：{"renamed": [(old, new), ...], "skipped": [name, ...]}
        """
        result = {"renamed": [], "skipped": []}
        if suffix is None:
            suffix = self.rename_suffix or ''
        suffix = (suffix or '').strip()
        if not suffix:
            return result
        if not self.detect_maya():
            return result
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')

            # 解析选择为 transforms（兼容 shape/组件）
            transforms = cmds.ls(selection=True, type='transform', long=True) or []
            if not transforms:
                sel = cmds.ls(selection=True, long=True) or []
                parents = set()
                for s in sel:
                    try:
                        objs = cmds.ls(s, objectsOnly=True, long=True) or []
                        for o in objs:
                            if cmds.nodeType(o) == 'transform':
                                parents.add(o)
                            else:
                                for p in cmds.listRelatives(o, parent=True, fullPath=True) or []:
                                    parents.add(p)
                    except Exception:
                        pass
                transforms = sorted(list(parents))

            # 执行重命名
            existing = set(cmds.ls(long=False) or [])
            for tr in transforms:
                short = cmds.ls(tr, shortNames=True)[0] if cmds.ls(tr, shortNames=True) else tr.split('|')[-1]
                if short.endswith(suffix):
                    result["skipped"].append(short)
                    continue
                base = short + suffix
                new_name = base
                if new_name in existing:
                    idx = 1
                    while True:
                        new_name = f"{base}_{idx:03d}"
                        if new_name not in existing:
                            break
                        idx += 1
                try:
                    renamed = cmds.rename(tr, new_name)
                    result["renamed"].append((short, renamed.split('|')[-1]))
                    existing.add(renamed.split('|')[-1])
                except Exception:
                    result["skipped"].append(short)

            return result
        except Exception:
            return result

    def add_prefix_to_selected(self, prefix: Optional[str] = None) -> dict:
        """为当前选择的 Transform 对象批量添加前缀。

        规则：
        - 仅处理 transform（会从 shape/组件选择回溯到 transform）。
        - 已有相同前缀的不会重复添加。
        - 如发生重名，自动在末尾加 _001, _002 保证唯一。

        返回：{"renamed": [(old, new), ...], "skipped": [name, ...]}
        """
        result = {"renamed": [], "skipped": []}
        if prefix is None:
            prefix = self.rename_prefix or ''
        prefix = (prefix or '').strip()
        if not prefix:
            return result
        if not self.detect_maya():
            return result
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')

            # 解析选择为 transforms（兼容 shape/组件）
            transforms = cmds.ls(selection=True, type='transform', long=True) or []
            if not transforms:
                sel = cmds.ls(selection=True, long=True) or []
                parents = set()
                for s in sel:
                    try:
                        objs = cmds.ls(s, objectsOnly=True, long=True) or []
                        for o in objs:
                            if cmds.nodeType(o) == 'transform':
                                parents.add(o)
                            else:
                                for p in cmds.listRelatives(o, parent=True, fullPath=True) or []:
                                    parents.add(p)
                    except Exception:
                        pass
                transforms = sorted(list(parents))

            # 执行重命名
            existing = set(cmds.ls(long=False) or [])
            for tr in transforms:
                short = cmds.ls(tr, shortNames=True)[0] if cmds.ls(tr, shortNames=True) else tr.split('|')[-1]
                if short.startswith(prefix):
                    result["skipped"].append(short)
                    continue
                base = prefix + short
                new_name = base
                if new_name in existing:
                    idx = 1
                    while True:
                        new_name = f"{base}_{idx:03d}"
                        if new_name not in existing:
                            break
                        idx += 1
                try:
                    renamed = cmds.rename(tr, new_name)
                    result["renamed"].append((short, renamed.split('|')[-1]))
                    existing.add(renamed.split('|')[-1])
                except Exception:
                    result["skipped"].append(short)

            return result
        except Exception:
            return result
    
    def run_all_checks(self):
        """运行所有检查"""
        self.results = []
        
        if not self.detect_maya():
            self.results.append("❌ 未检测到 Maya 环境")
            return self.results
        
        # 可选：检查Maya单位
        if self.enable_unit_check:
            self._check_maya_units()
        
        # 运行配置文件中的检查
        for check in (self.checks or []):
            # 仅处理 Maya 支持的检查类型
            self._run_maya_check(check)
        
        if not self.results:
            self.results.append("✅ 所有检查通过！")
            
        return self.results
    
    def _check_maya_units(self):
        """检查Maya单位设置"""
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            unit = cmds.currentUnit(query=True, linear=True)
            if unit != "m":
                self.results.append(f"❌ Maya: 单位不是米 ({unit})")
            else:
                self.results.append("✅ Maya: 单位为米")
        except Exception as e:
            self.results.append(f"ℹ️ Maya: 无法检测单位 ({e})")

    def set_units_to_meters(self):
        """将 Maya 线性单位设置为米(m)。

        返回:
            (ok: bool, previous_unit: str|None)
        """
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            prev = cmds.currentUnit(query=True, linear=True)
            # 设置为米；保持角度/时间单位不变
            cmds.currentUnit(linear='m')
            return True, prev
        except Exception:
            return False, None
    
    def _run_maya_check(self, check):
        """运行单个Maya检查"""
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
        except Exception:
            return
            
        check_type = (check.get("check_type") or check.get('type') or "").strip()
        
        if check_type == "uv_sets":
            self._check_uv_sets(check, cmds)
        elif check_type == "poly_faces":
            self._check_poly_faces(check, cmds)
    
    def _check_uv_sets(self, check, cmds):
        """检查UV集数量"""
        limit = int(check.get("limit") or 0)
        suffix = check.get("target") or ""

        # 以 transform 为单位进行过滤（与 poly_faces 保持一致）
        transforms = cmds.ls(transforms=True, long=True) or []
        matched_trs = [t for t in transforms if t.endswith(suffix)] if suffix else transforms

        for tr in matched_trs:
            shapes = cmds.listRelatives(tr, shapes=True, fullPath=True) or []
            for shape in shapes:
                if cmds.nodeType(shape) != 'mesh':
                    continue
                try:
                    uvs = cmds.polyUVSet(shape, query=True, allUVSets=True) or []
                except Exception:
                    uvs = []

                if len(uvs) != limit:
                    self.results.append(f"❌ {tr}: UV 集数量 = {len(uvs)}, 期望 {limit}")
                else:
                    self.results.append(f"✅ {tr}: UV 集数量符合要求")
    
    def _check_poly_faces(self, check, cmds):
        """检查多边形面数"""
        suffix = check.get("target") or ""
        limit = int(check.get("limit") or 0)
        transforms = cmds.ls(transforms=True, long=True) or []
        matched = [t for t in transforms if t.endswith(suffix)]

        for tr in matched:
            shapes = cmds.listRelatives(tr, shapes=True, fullPath=True) or []
            for sh in shapes:
                try:
                    face_count = cmds.polyEvaluate(sh, face=True)
                except Exception:
                    face_count = 0

                if face_count > limit:
                    self.results.append(f"❌ {tr}: 面数 {face_count}, 超过上限 {limit}")
                else:
                    self.results.append(f"✅ {tr}: 面数 {face_count}, 在上限 {limit} 内")
    
    def get_selection_info(self):
        """获取当前选择的对象信息"""
        try:
            from importlib import import_module
            cmds = import_module('maya.cmds')
            selected = cmds.ls(selection=True, transforms=True)
            
            info = {
                'count': len(selected),
                'objects': selected,
                'details': []
            }
            
            for obj in selected:
                obj_info = {
                    'name': obj,
                    'type': cmds.nodeType(obj),
                    'pivot': cmds.xform(obj, query=True, worldSpace=True, rotatePivot=True),
                    'bbox': None,
                    'face_count': 0
                }
                
                try:
                    obj_info['bbox'] = cmds.exactWorldBoundingBox(obj)
                except:
                    pass
                
                # 获取面数
                shapes = cmds.listRelatives(obj, shapes=True, fullPath=True) or []
                for shape in shapes:
                    try:
                        if cmds.nodeType(shape) == 'mesh':
                            obj_info['face_count'] += cmds.polyEvaluate(shape, face=True)
                    except:
                        pass
                
                info['details'].append(obj_info)
            
            return info
            
        except Exception:
            return {'count': 0, 'objects': [], 'details': []}