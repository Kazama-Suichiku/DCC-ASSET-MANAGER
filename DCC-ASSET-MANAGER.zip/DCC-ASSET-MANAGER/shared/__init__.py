"""DCC Asset Manager - Shared Module"""
