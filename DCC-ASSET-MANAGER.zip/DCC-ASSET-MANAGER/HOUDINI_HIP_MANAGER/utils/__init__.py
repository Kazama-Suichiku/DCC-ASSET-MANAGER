"""Houdini HIP Manager - Utils Module"""
