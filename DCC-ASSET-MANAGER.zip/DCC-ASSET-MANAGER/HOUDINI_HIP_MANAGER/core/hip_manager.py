import os
import hou
from PySide6 import QtWidgets, QtGui, QtCore
from datetime import datetime
from HOUDINI_HIP_MANAGER.ui.widgets import FloatingIcon, LogDisplayWidget, HipLoaderThread
from HOUDINI_HIP_MANAGER.ui.dialogs import SnapshotViewer
from HOUDINI_HIP_MANAGER.utils.hip_utils import get_recent_hips, get_snapshot_path, generate_hip_snapshot, safe_load_hip, delete_hip_file
from shared.p4v_utils import launch_p4v
from .asset_checker import AssetChecker

class HipManager(QtWidgets.QMainWindow):
    """HIP文件管理器主类"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Houdini HIP 管理器")
        self.setMinimumSize(600, 450)
        
        self.setWindowFlags(QtCore.Qt.Window | QtCore.Qt.WindowStaysOnTopHint)
        
        central_widget = QtWidgets.QWidget()
        self.setCentralWidget(central_widget)
        self._thread = None
        self._selected_paths = set()
        self.is_minimized_to_icon = False
        self.force_quit = False
        
        # 初始化资产检查器
        self.asset_checker = AssetChecker(self)
        
        # 初始化浮动图标
        self.floating_icon = FloatingIcon(self)
        self.floating_icon.hide()

        self.init_ui(central_widget)

    def init_ui(self, central_widget):
        """初始化UI"""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f0f0f0;
                font-family: Arial, sans-serif;
                color: black;
            }
            QWidget {
                background-color: #f0f0f0;
                font-family: Arial, sans-serif;
                color: black;
            }
            QPushButton {
                background-color: #007BFF;
                color: white;
                border-radius: 4px;
                padding: 6px 8px;
                margin: 2px;
                min-width: 80px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
            QPushButton#deleteButton {
                background-color: #dc3545;
            }
            QPushButton#deleteButton:hover {
                background-color: #c82333;
            }
            QPushButton[text="最小化到图标"] {
                background-color: #6c757d;
            }
            QPushButton[text="最小化到图标"]:hover {
                background-color: #545b62;
            }
            QPushButton[text="打开P4V"] {
                background-color: #17a2b8;
            }
            QPushButton[text="打开P4V"]:hover {
                background-color: #138496;
            }
            QLineEdit {
                padding: 6px;
                border: 1px solid #007BFF;
                border-radius: 4px;
                font-size: 12px;
                background-color: white;
                color: black;
            }
            QComboBox {
                padding: 6px;
                border: 1px solid #007BFF;
                border-radius: 4px;
                font-size: 12px;
                background-color: white;
                color: black;
            }
            QFrame {
                background-color: white;
                border: 2px solid #007BFF;
                border-radius: 8px;
                margin: 5px;
            }
            QFrame:hover {
                border: 2px solid #FF6200;
            }
            QLabel {
                font-size: 12px;
                color: black;
                padding: 3px;
            }
            QProgressBar {
                border: 1px solid #007BFF;
                border-radius: 4px;
                text-align: center;
                background-color: white;
                color: black;
                font-size: 12px;
            }
            QCheckBox {
                margin: 3px;
                font-size: 12px;
            }
            QTabWidget::pane {
                border: 1px solid #007BFF;
                background-color: white;
            }
            QTabWidget::tab-bar {
                alignment: center;
            }
            QTabBar::tab {
                background: #007BFF;
                color: white;
                padding: 6px 12px;
                margin: 1px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                font-size: 12px;
            }
            QTabBar::tab:selected {
                background: #0056b3;
            }
            QMessageBox {
                font-size: 16px;
            }
        """)

        layout = QtWidgets.QVBoxLayout(central_widget)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        self.tabs = QtWidgets.QTabWidget()
        self.recent_tab = QtWidgets.QWidget()
        self.asset_tab = QtWidgets.QWidget()
        self.tabs.addTab(self.recent_tab, "Recent HIPs")
        self.tabs.addTab(self.asset_tab, "Asset Checker")
        
        self.init_recent_tab()
        self.init_asset_tab()

        layout.addWidget(self.tabs)
        
        bottom_layout = QtWidgets.QHBoxLayout()
        bottom_layout.setSpacing(8)
        
        minimize_btn = QtWidgets.QPushButton("最小化到图标")
        minimize_btn.clicked.connect(self.minimizeToIcon)
        bottom_layout.addWidget(minimize_btn)
        
        p4v_btn = QtWidgets.QPushButton("打开P4V")
        p4v_btn.clicked.connect(self.launch_p4v)
        bottom_layout.addWidget(p4v_btn)
        
        bottom_layout.addStretch()
        
        layout.addLayout(bottom_layout)

        QtCore.QTimer.singleShot(0, self.populate)

    def init_recent_tab(self):
        """初始化最近文件标签页"""
        recent_layout = QtWidgets.QVBoxLayout(self.recent_tab)
        recent_layout.setSpacing(6)
        recent_layout.setContentsMargins(6, 6, 6, 6)
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.setSpacing(6)
        
        refresh_btn = QtWidgets.QPushButton("刷新列表")
        refresh_btn.clicked.connect(self.populate)
        
        self.search_input = QtWidgets.QLineEdit()
        self.search_input.setPlaceholderText("输入关键字搜索 HIP 文件")
        self.search_input.textChanged.connect(self.search_hips)
        
        self.sort_combo = QtWidgets.QComboBox()
        self.sort_combo.addItems(["按时间排序", "按名称排序", "按大小排序"])
        self.sort_combo.currentIndexChanged.connect(self.populate)
        
        save_btn = QtWidgets.QPushButton("保存 HIP 文件")
        save_btn.clicked.connect(self.save_hip)
        
        delete_selected_btn = QtWidgets.QPushButton("删除选中")
        delete_selected_btn.setObjectName("deleteButton")
        delete_selected_btn.clicked.connect(self.delete_selected)
        
        btn_layout.addWidget(refresh_btn)
        btn_layout.addWidget(self.search_input, 1)
        btn_layout.addWidget(self.sort_combo)
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(delete_selected_btn)

        self.status_label = QtWidgets.QLabel("")
        self.status_label.setStyleSheet("color: black; font-size: 11px; padding: 2px;")
        self.status_label.setWordWrap(True)
        self.status_label.setMaximumHeight(30)
        
        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setMinimum(0)
        self.progress_bar.setTextVisible(True)
        
        self.grid = QtWidgets.QGridLayout()
        self.grid.setSpacing(6)
        
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        container = QtWidgets.QWidget()
        container.setLayout(self.grid)
        scroll.setWidget(container)

        recent_layout.addLayout(btn_layout)
        recent_layout.addWidget(self.status_label)
        recent_layout.addWidget(self.progress_bar)
        recent_layout.addWidget(scroll)

    def init_asset_tab(self):
        """初始化资产检查标签页"""
        asset_layout = QtWidgets.QVBoxLayout(self.asset_tab)
        asset_layout.setSpacing(6)
        asset_layout.setContentsMargins(6, 6, 6, 6)
        
        asset_btn_layout = QtWidgets.QHBoxLayout()
        asset_btn_layout.setSpacing(6)
        
        check_btn = QtWidgets.QPushButton("检查选中节点")
        check_btn.clicked.connect(self.check_selected_node)
        
        config_btn = QtWidgets.QPushButton("配置允许属性")
        config_btn.clicked.connect(self.configure_allowed_attributes)
        
        export_btn = QtWidgets.QPushButton("导出资产")
        export_btn.clicked.connect(self.export_asset)
        
        asset_btn_layout.addWidget(check_btn)
        asset_btn_layout.addWidget(config_btn)
        asset_btn_layout.addWidget(export_btn)

        self.asset_status_label = QtWidgets.QLabel("")
        self.asset_status_label.setStyleSheet("color: black; font-size: 11px; padding: 2px;")
        self.asset_status_label.setWordWrap(True)
        self.asset_status_label.setMaximumHeight(30)
        
        self.log_widget = LogDisplayWidget(self)
        
        asset_layout.addLayout(asset_btn_layout)
        asset_layout.addWidget(self.asset_status_label)
        asset_layout.addWidget(self.log_widget)

    def minimizeToIcon(self):
        """最小化到浮动图标"""
        self.hide()
        self.is_minimized_to_icon = True
        self.floating_icon.show()
        self.floating_icon.raise_()
    
    def force_quit_application(self):
        """强制退出应用程序"""
        self.force_quit = True
        self.close()

    def populate(self):
        """填充HIP文件列表"""
        if self._thread and self._thread.isRunning():
            self._thread.requestInterruption()
            self._thread.wait()

        while self.grid.count():
            child = self.grid.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        self._selected_paths.clear()
        sort_by = {"按时间排序": "time", "按名称排序": "name", "按大小排序": "size"}[self.sort_combo.currentText()]
        hips = get_recent_hips(keyword=self.search_input.text().strip(), sort_by=sort_by)
        if not hips:
            self.status_label.setText("未找到最近的 .hip 文件")
            QtCore.QTimer.singleShot(5000, lambda: self.status_label.setText(""))
            lbl = QtWidgets.QLabel("未找到最近的 .hip 文件")
            lbl.setAlignment(QtCore.Qt.AlignCenter)
            lbl.setStyleSheet("font-size: 11px;")
            self.grid.addWidget(lbl, 0, 0)
            return

        self._thread = HipLoaderThread(hips)
        self._thread.hip_loaded.connect(self.add_hip_card)
        self._thread.error.connect(self.add_error_card)
        self._thread.progress.connect(self.update_progress)
        self._thread.finished.connect(self.on_thread_finished)
        self.progress_bar.setMaximum(len(hips))
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        self.search_input.setEnabled(False)
        self.sort_combo.setEnabled(False)
        self._thread.start()

        self.status_label.setText(f"正在加载 {len(hips)} 个文件")

    def search_hips(self):
        """搜索HIP文件"""
        if self._thread and self._thread.isRunning():
            self._thread.requestInterruption()
            self._thread.wait()

        while self.grid.count():
            child = self.grid.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        self._selected_paths.clear()
        sort_by = {"按时间排序": "time", "按名称排序": "name", "按大小排序": "size"}[self.sort_combo.currentText()]
        keyword = self.search_input.text().strip()
        hips = get_recent_hips(keyword=keyword if keyword else None, sort_by=sort_by)
        if not hips:
            self.status_label.setText(f"未找到包含 '{keyword}' 的 .hip 文件" if keyword else "未找到最近的 .hip 文件")
            QtCore.QTimer.singleShot(5000, lambda: self.status_label.setText(""))
            lbl = QtWidgets.QLabel(f"未找到包含 '{keyword}' 的 .hip 文件" if keyword else "未找到最近的 .hip 文件")
            lbl.setAlignment(QtCore.Qt.AlignCenter)
            lbl.setStyleSheet("font-size: 11px;")
            self.grid.addWidget(lbl, 0, 0)
            return

        self._thread = HipLoaderThread(hips)
        self._thread.hip_loaded.connect(self.add_hip_card)
        self._thread.error.connect(self.add_error_card)
        self._thread.progress.connect(self.update_progress)
        self._thread.finished.connect(self.on_thread_finished)
        self.progress_bar.setMaximum(len(hips))
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        self.search_input.setEnabled(False)
        self.sort_combo.setEnabled(False)
        self._thread.start()

        self.status_label.setText(f"正在加载 {len(hips)} 个文件（搜索：{keyword or '无'}）")

    def update_progress(self, current, total):
        """更新进度条"""
        self.progress_bar.setValue(current)
        self.progress_bar.setFormat(f"加载中: %v/%m (%p%)")

    def on_thread_finished(self):
        """线程完成时的处理"""
        self.progress_bar.setVisible(False)
        self.search_input.setEnabled(True)
        self.sort_combo.setEnabled(True)
        self.status_label.setText(f"加载完成: {self.progress_bar.maximum()} 个文件")
        QtCore.QTimer.singleShot(5000, lambda: self.status_label.setText(""))

    def add_hip_card(self, hip_path, snapshot_path):
        """添加HIP文件卡片"""
        r = self.grid.count() // 3
        c = self.grid.count() % 3
        self.grid.addWidget(self.make_card(hip_path, snapshot_path), r, c)

    def add_error_card(self, hip_path, error_message):
        """添加错误卡片"""
        r = self.grid.count() // 3
        c = self.grid.count() % 3
        frame = QtWidgets.QFrame()
        frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        v = QtWidgets.QVBoxLayout(frame)
        v.setSpacing(6)
        v.setContentsMargins(6, 6, 6, 6)

        lbl_img = QtWidgets.QLabel()
        lbl_img.setObjectName(f"image_{hip_path}")
        pix = QtGui.QPixmap(160, 90)
        pix.fill(QtGui.QColor("darkgray"))
        lbl_img.setPixmap(pix.scaled(240, 135, QtCore.Qt.KeepAspectRatio))
        lbl_img.setAlignment(QtCore.Qt.AlignCenter)
        lbl_img.setCursor(QtCore.Qt.PointingHandCursor)
        lbl_img.mousePressEvent = lambda event: self.show_enlarged_snapshot(get_snapshot_path(hip_path))

        lbl_name = QtWidgets.QLabel(f"{os.path.basename(hip_path)}\n{error_message}")
        lbl_name.setAlignment(QtCore.Qt.AlignCenter)
        lbl_name.setStyleSheet("font-weight: bold; font-size: 11px; padding: 3px;")
        lbl_name.setWordWrap(True)

        info_label = QtWidgets.QLabel()
        file_size = os.path.getsize(hip_path) / (1024 * 1024) if os.path.exists(hip_path) else 0
        mtime = datetime.fromtimestamp(os.path.getmtime(hip_path)).strftime("%Y-%m-%d %H:%M:%S") if os.path.exists(hip_path) else "未知"
        ctime = datetime.fromtimestamp(os.path.getctime(hip_path)).strftime("%Y-%m-%d %H:%M:%S") if os.path.exists(hip_path) else "未知"
        info_label.setText(f"大小: {file_size:.2f} MB | 修改: {mtime}")
        info_label.setAlignment(QtCore.Qt.AlignCenter)
        info_label.setStyleSheet("font-size: 10px; color: #555; padding: 3px;")
        info_label.setWordWrap(True)

        checkbox = QtWidgets.QCheckBox()
        checkbox.toggled.connect(lambda checked: self.toggle_selection(hip_path, checked))

        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.setSpacing(4)
        open_btn = QtWidgets.QPushButton("打开")
        open_btn.clicked.connect(lambda: self.open_hip(hip_path))
        copy_btn = QtWidgets.QPushButton("复制路径")
        copy_btn.clicked.connect(lambda: self.copy_hip_path(hip_path))
        delete_btn = QtWidgets.QPushButton("删除")
        delete_btn.setObjectName("deleteButton")
        delete_btn.clicked.connect(lambda: self.delete_hip(hip_path))
        btn_layout.addWidget(open_btn)
        btn_layout.addWidget(copy_btn)
        btn_layout.addWidget(delete_btn)

        v.addWidget(checkbox)
        v.addWidget(lbl_img)
        v.addWidget(lbl_name)
        v.addWidget(info_label)
        v.addLayout(btn_layout)

        frame.setToolTip(f"路径: {hip_path}\n大小: {file_size:.2f} MB\n创建时间: {ctime}\n修改时间: {mtime}\n类型: {os.path.splitext(hip_path)[1]}")

        self.grid.addWidget(frame, r, c)

    def make_card(self, path, snapshot_path):
        """创建HIP文件卡片"""
        frame = QtWidgets.QFrame()
        frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        v = QtWidgets.QVBoxLayout(frame)
        v.setSpacing(6)
        v.setContentsMargins(6, 6, 6, 6)

        lbl_img = QtWidgets.QLabel()
        lbl_img.setObjectName(f"image_{path}")
        if snapshot_path and os.path.exists(snapshot_path):
            pix = QtGui.QPixmap(snapshot_path)
            if pix.isNull():
                pix = QtGui.QPixmap(160, 90)
                pix.fill(QtGui.QColor("darkgray"))
        else:
            pix = QtGui.QPixmap(160, 90)
            pix.fill(QtGui.QColor("darkgray"))
        lbl_img.setPixmap(pix.scaled(240, 135, QtCore.Qt.KeepAspectRatio))
        lbl_img.setAlignment(QtCore.Qt.AlignCenter)
        lbl_img.setCursor(QtCore.Qt.PointingHandCursor)
        lbl_img.mousePressEvent = lambda event: self.show_enlarged_snapshot(snapshot_path)

        lbl_name = QtWidgets.QLabel(os.path.basename(path))
        lbl_name.setAlignment(QtCore.Qt.AlignCenter)
        lbl_name.setStyleSheet("font-weight: bold; font-size: 11px; padding: 3px;")
        lbl_name.setWordWrap(True)

        info_label = QtWidgets.QLabel()
        file_size = os.path.getsize(path) / (1024 * 1024) if os.path.exists(path) else 0
        mtime = datetime.fromtimestamp(os.path.getmtime(path)).strftime("%Y-%m-%d %H:%M:%S") if os.path.exists(path) else "未知"
        ctime = datetime.fromtimestamp(os.path.getctime(path)).strftime("%Y-%m-%d %H:%M:%S") if os.path.exists(path) else "未知"
        info_label.setText(f"大小: {file_size:.2f} MB | 修改: {mtime}")
        info_label.setAlignment(QtCore.Qt.AlignCenter)
        info_label.setStyleSheet("font-size: 10px; color: #555; padding: 3px;")
        info_label.setWordWrap(True)

        checkbox = QtWidgets.QCheckBox()
        checkbox.toggled.connect(lambda checked: self.toggle_selection(path, checked))

        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.setSpacing(4)
        open_btn = QtWidgets.QPushButton("打开")
        open_btn.clicked.connect(lambda: self.open_hip(path))
        copy_btn = QtWidgets.QPushButton("复制路径")
        copy_btn.clicked.connect(lambda: self.copy_hip_path(path))
        delete_btn = QtWidgets.QPushButton("删除")
        delete_btn.setObjectName("deleteButton")
        delete_btn.clicked.connect(lambda: self.delete_hip(path))
        btn_layout.addWidget(open_btn)
        btn_layout.addWidget(copy_btn)
        btn_layout.addWidget(delete_btn)

        v.addWidget(checkbox)
        v.addWidget(lbl_img)
        v.addWidget(lbl_name)
        v.addWidget(info_label)
        v.addLayout(btn_layout)

        frame.setToolTip(f"路径: {path}\n大小: {file_size:.2f} MB\n创建时间: {ctime}\n修改时间: {mtime}\n类型: {os.path.splitext(path)[1]}")

        return frame

    def toggle_selection(self, path, checked):
        """切换文件选择状态"""
        if checked:
            self._selected_paths.add(path)
        else:
            self._selected_paths.discard(path)

    def show_enlarged_snapshot(self, snapshot_path):
        """显示放大的快照"""
        viewer = SnapshotViewer(snapshot_path, self)
        viewer.exec_()

    def open_hip(self, path):
        """打开HIP文件"""
        if safe_load_hip(path, self):
            self.minimizeToIcon()

    def copy_hip_path(self, path):
        """复制HIP文件路径"""
        try:
            clipboard = QtWidgets.QApplication.clipboard()
            clipboard.setText(path)
            self.status_label.setText(f"路径已复制: {os.path.basename(path)}")
            QtCore.QTimer.singleShot(5000, lambda: self.status_label.setText(""))
        except Exception as e:
            self.status_label.setText(f"复制路径失败: {os.path.basename(path)}")
            QtCore.QTimer.singleShot(5000, lambda: self.status_label.setText(""))

    def delete_hip(self, path):
        """删除单个HIP文件"""
        msg_box = QtWidgets.QMessageBox(self)
        msg_box.setWindowTitle("确认删除")
        msg_box.setText(f"确定删除文件 {os.path.basename(path)}？\n此操作不可撤销！")
        msg_box.setStandardButtons(QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        msg_box.setDefaultButton(QtWidgets.QMessageBox.No)
        if msg_box.exec_() == QtWidgets.QMessageBox.Yes:
            if delete_hip_file(path, self):
                self._selected_paths.discard(path)
                self.status_label.setText(f"已删除: {os.path.basename(path)}")
                QtCore.QTimer.singleShot(5000, lambda: self.status_label.setText(""))
                self.populate()
            else:
                self.status_label.setText(f"删除失败: {os.path.basename(path)}")
                QtCore.QTimer.singleShot(5000, lambda: self.status_label.setText(""))

    def delete_selected(self):
        """删除选中的HIP文件"""
        if not self._selected_paths:
            self.status_label.setText("未选择任何文件")
            QtCore.QTimer.singleShot(5000, lambda: self.status_label.setText(""))
            return
        msg_box = QtWidgets.QMessageBox(self)
        msg_box.setWindowTitle("确认删除")
        msg_box.setText(f"确定删除 {len(self._selected_paths)} 个选中文件？\n此操作不可撤销！")
        msg_box.setStandardButtons(QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        msg_box.setDefaultButton(QtWidgets.QMessageBox.No)
        if msg_box.exec_() == QtWidgets.QMessageBox.Yes:
            success_count = 0
            for path in list(self._selected_paths):
                if delete_hip_file(path, self):
                    success_count += 1
            self._selected_paths.clear()
            self.status_label.setText(f"已删除 {success_count} 个文件，{len(self._selected_paths)} 个失败")
            QtCore.QTimer.singleShot(5000, lambda: self.status_label.setText(""))
            self.populate()

    def configure_allowed_attributes(self):
        """配置允许的属性"""
        if self.asset_checker.configure_allowed_attributes():
            self.log_widget.add_log("属性配置已更新并保存", "success")
            self.asset_status_label.setText("属性配置已更新")
            QtCore.QTimer.singleShot(5000, lambda: self.asset_status_label.setText(""))

    def check_selected_node(self):
        """检查选中的节点"""
        self.asset_checker.check_selected_node(self.log_widget, self.asset_status_label)

    def export_asset(self):
        """导出资产"""
        self.asset_checker.export_asset(self.log_widget, self.asset_status_label)

    def save_hip(self):
        """保存HIP文件 - 智能保存模式"""
        try:
            current_hip_path = hou.hipFile.path()
            current_hip_name = hou.hipFile.name()
            
            if current_hip_path and current_hip_path != "untitled.hip" and os.path.exists(current_hip_path):
                msg_box = QtWidgets.QMessageBox(self)
                msg_box.setWindowTitle("保存HIP文件")
                msg_box.setText(f"当前文件：{os.path.basename(current_hip_path)}")
                msg_box.setInformativeText("请选择保存方式：")
                msg_box.setIcon(QtWidgets.QMessageBox.Question)
                
                overwrite_btn = msg_box.addButton("覆盖当前文件", QtWidgets.QMessageBox.AcceptRole)
                save_as_btn = msg_box.addButton("另存为...", QtWidgets.QMessageBox.ActionRole)
                cancel_btn = msg_box.addButton("取消", QtWidgets.QMessageBox.RejectRole)
                
                msg_box.setDefaultButton(overwrite_btn)
                msg_box.exec_()
                
                clicked_button = msg_box.clickedButton()
                
                if clicked_button == overwrite_btn:
                    self._save_and_update(current_hip_path, "覆盖")
                elif clicked_button == save_as_btn:
                    self._save_as_new_file()
                
            else:
                self._save_as_new_file()
                
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self, "错误", 
                f"获取当前文件信息失败:\n{str(e)}", 
                QtWidgets.QMessageBox.Ok
            )
    
    def _save_and_update(self, save_path, save_type="保存"):
        """保存文件并更新快照"""
        try:
            self.status_label.setText(f"正在{save_type}文件...")
            hou.hipFile.save(save_path)
            
            try:
                prefs = hou.getenv("HOUDINI_USER_PREF_DIR") or os.getcwd()
            except:
                prefs = os.getcwd()
            
            hist_file = os.path.join(prefs, "file.history")
            with open(hist_file, "a", encoding="utf-8") as f:
                f.write(f"{save_path}\n")
            
            self.status_label.setText("正在生成快照...")
            snapshot = generate_hip_snapshot(save_path, force=True)
            
            if snapshot:
                self.status_label.setText(f"已{save_type}并更新快照: {os.path.basename(save_path)}")
            else:
                self.status_label.setText(f"{save_type}成功，但快照生成失败: {os.path.basename(save_path)}")
                
            QtCore.QTimer.singleShot(5000, lambda: self.status_label.setText(""))
            self.populate()  # 刷新文件列表
            
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self, "错误", 
                f"{save_type}失败:\n{str(e)}", 
                QtWidgets.QMessageBox.Ok
            )
            self.status_label.setText(f"{save_type}失败")
            QtCore.QTimer.singleShot(3000, lambda: self.status_label.setText(""))
    
    def _save_as_new_file(self):
        """另存为新文件"""
        save_path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "另存为 HIP 文件", "", "Houdini Scene (*.hip *.hiplc *.hipnc)"
        )
        if save_path:
            self._save_and_update(save_path, "另存为")

    def launch_p4v(self):
        """启动P4V程序"""
        result = launch_p4v(self)
        
        if result == "already_running":
            self.status_label.setText("P4V进程已经在运行，无需重复启动")
            QtCore.QTimer.singleShot(3000, lambda: self.status_label.setText(""))
        elif result:
            self.status_label.setText("正在启动P4V程序...")
            QtCore.QTimer.singleShot(3000, lambda: self.status_label.setText(""))
        else:
            self.status_label.setText("P4V启动失败")
            QtCore.QTimer.singleShot(3000, lambda: self.status_label.setText(""))

    def closeEvent(self, event):
        """关闭事件处理"""
        if hasattr(self, 'force_quit') and self.force_quit:
            if self._thread and self._thread.isRunning():
                self._thread.requestInterruption()
                self._thread.wait()
            
            if hasattr(self, 'floating_icon') and self.floating_icon:
                self.floating_icon.close()
                self.floating_icon = None
            
            event.accept()
            super().closeEvent(event)
        else:
            event.ignore()
            self.minimizeToIcon()
