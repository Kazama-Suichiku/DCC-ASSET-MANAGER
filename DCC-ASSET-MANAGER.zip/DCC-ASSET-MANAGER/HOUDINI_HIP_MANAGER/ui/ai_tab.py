# -*- coding: utf-8 -*-
"""
Houdini AI 助手 Tab

注意：出于安全考虑，不要将 API Key 明文提交到仓库。建议使用环境变量 OPENAI_API_KEY、DEEPSEEK_API_KEY 等。
"""

import json
import re

from PySide6 import QtWidgets, QtCore, QtGui

from ..utils.ai_client import OpenAIClient
from ..utils.mcp import HoudiniMCP
from .chat_window import ChatWindow
from .widgets import LoadingSpinner


class AITab(QtWidgets.QWidget):
    # 定义信号用于跨线程通信
    _responseReady = QtCore.Signal(dict)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.client = OpenAIClient()
        self.mcp = HoudiniMCP()
        self._conversation_history = []  # 维护完整的对话历史（发送给 AI）
        self._display_history = []  # 维护显示历史（包括 Context 消息，用于全屏窗口）
        
        # 连接响应信号
        self._responseReady.connect(self._after_send)
        
        self._base_system_prompt = (
            "你是 Houdini 技术助理。回答必须基于用户提供的实际信息。\n\n"
            "## 关键约束\n"
            "- 如果用户消息中包含节点信息（以 '===' 开头的节点描述块），你必须且只能基于这些节点回答\n"
            "- 如果用户消息中包含 [文档查询] 标记，说明这是官方文档内容，必须优先参考\n"
            "- 禁止编造、假设或推测不存在的节点\n"
            "- 回答时必须引用节点的实际名称和类型（例如：'compile_end1 是 sop/compile_end 类型'）\n"
            "- 如果用户问题与提供的节点不符，明确指出不匹配\n"
            "- 当遇到带命名空间的节点（如 sop/labs::splatter）时，建议用户使用'查询文档'功能，并告知可直接输入完整类型如 'sop/labs::splatter'\n\n"
            "## 可用工具\n"
            "用户可以使用以下工具获取准确信息：\n"
            "1. **读取选中节点** - 获取场景中选中节点的详细信息（包括错误信息、烹饪状态等）\n"
            "2. **搜索节点类型** - 搜索 Houdini 中可用的节点类型\n"
            "3. **查询文档** - 查询 Houdini 官方文档，获取节点的详细说明和参数\n"
            "4. **创建节点** - 手动创建单个节点\n\n"
            "**读取节点信息说明：** 如果节点有错误，会显示 ⚠️ 标记和具体错误信息。当用户询问节点问题或报错时，务必先建议用户使用此功能。\n"
            "当用户询问某个节点的详细用法时，建议用户使用'查询文档'功能获取官方文档。\n"
            "**注意：** 对于 Labs 节点（如 labs::splatter），查询时输入完整类型 'sop/labs::splatter' 即可自动识别。\n\n"
            "## MCP 指令说明\n"
            "**⚠️ 致命约束：只能使用以下 4 个 action，一个字都不能错！**\n\n"
            "### 可用的 MCP Actions（仅此4个，严格匹配）：\n"
            "1. `create_nodes` - 创建节点网络\n"
            "2. `set_parameter` - 修改节点参数\n"
            "3. `connect_nodes` - 连接节点\n"
            "4. `delete_node` - 删除节点\n\n"
            "**❌ 禁止使用的错误拼写（这些都会导致失败）：**\n"
            "- ❌ set_parm（缺少 eter）\n"
            "- ❌ set_parms（多了 s）\n"
            "- ❌ set_params（错误缩写）\n"
            "- ❌ update_param、modify_param（动词错误）\n"
            "- ❌ create_node（缺少 s）\n"
            "- ❌ connect（缺少 _nodes）\n"
            "**✅ 正确示例：{\"action\":\"set_parameter\",...}**\n\n"
            "### 1. 创建节点网络\n"
            "触发条件：用户说'帮我搭xxx'、'创建xxx网络'、'建立xxx流程'、'创建示例'\n"
            "```mcp\n"
            "{\"action\":\"create_nodes\",\"nodes\":[{\"id\":\"n1\",\"type\":\"sop/box\",\"parms\":{\"size\":2}}],\"connections\":[{\"from\":\"n1\",\"to\":\"n2\",\"input\":0}]}\n"
            "```\n\n"
            "### 2. 修改节点参数（修复错误时使用）\n"
            "**⚠️ 关键约束：action 必须是 \"set_parameter\"（完整拼写,不能缩写）**\n"
            "**当用户要求修改/更新/修复节点时,必须使用此 MCP 动作:**\n"
            "```mcp\n"
            "{\"action\":\"set_parameter\",\"node_path\":\"/obj/geo1/attribwrangle1\",\"param_name\":\"snippet\",\"value\":\"@P.y += 5;\"}\n"
            "```\n"
            "**参数说明：**\n"
            "- `action`: **必须精确写 \"set_parameter\"（不是 set_parm/set_parms/set_params/update_param）**\n"
            "- `node_path`: 完整节点路径（从节点信息的 '节点路径：' 行获取）\n"
            "- `param_name`: 参数名（如 snippet、tx、ty、tz、npts 等）\n"
            "- `value`: 参数值（字符串用引号，数字不用）\n\n"
            "**常见参数名：**\n"
            "- `snippet` - VEX 代码（Attribute Wrangle）\n"
            "- `tx`, `ty`, `tz` - 平移坐标\n"
            "- `rx`, `ry`, `rz` - 旋转角度\n"
            "- `sx`, `sy`, `sz` - 缩放比例\n"
            "- `npts` - 点数量（Scatter）\n"
            "- `seed` - 随机种子\n\n"
            "**VEX 代码注意事项：**\n"
            "- 每行结尾必须有分号\n"
            "- 使用 \\n 表示换行\n"
            "- 移除末尾的无效字符或数字\n"
            "- 示例：\"@pscale = 0.1;\\n@Cd = {1,0,0};\"\n\n"
            "### 3. 连接节点\n"
            "```mcp\n"
            "{\"action\":\"connect_nodes\",\"from\":\"/obj/geo1/box1\",\"to\":\"/obj/geo1/transform1\",\"input\":0}\n"
            "```\n\n"
            "### 4. 删除节点\n"
            "```mcp\n"
            "{\"action\":\"delete_node\",\"node_path\":\"/obj/geo1/null1\"}\n"
            "```\n\n"
            "## MCP 建树规则\n"
            "格式：```mcp\\n{JSON内容}\\n```\n\n"
            "**JSON 格式要求（严格遵守）：**\n"
            "- ✅ 字符串值用双引号：{\"snippet\":\"@P.y += 5;\"}\n"
            "- ✅ 数字值不用引号：{\"npts\":200, \"ty\":5.5}\n"
            "- ✅ 数组用方括号：{\"t\":[0,0,0]}, {\"scale\":[1,2,3]}\n"
            "- ❌ 错误示例：{\"t\":0,0,0} ← 缺少方括号，JSON 无效！\n"
            "- ❌ 错误示例：{\"name\":OUT_Final} ← 字符串缺少引号\n"
            "- 在 VEX 代码中可以使用单引号，但 JSON 的键和值必须用双引号\n"
            "- 多行 VEX 代码用 \\n 换行：{\"snippet\":\"@pscale = 0.5;\\n@Cd = {1,0,0};\"}\n\n"
            "**节点参数：** 使用 \"parms\" 或 \"parameters\" 字段均可（建议用 parms 更简洁）。例如：\n"
            "- attribwrangle: {\"parms\":{\"snippet\":\"@P.y += 5;\"}}\n"
            "- scatter: {\"parms\":{\"npts\":200}}\n"
            "- transform: {\"parms\":{\"ty\":5, \"t\":[0,1,0]}}\n"
            "- box: {\"parms\":{\"type\":1, \"size\":5, \"t\":[0,0,0]}}\n\n"
            "**关键：只能使用真实存在的 Houdini 节点类型！**\n"
            "常用 SOP 节点（仅列举部分，格式为 sop/节点名）：\n"
            "- 几何体：box, sphere, grid, tube, torus, platonic\n"
            "- 变换：transform, xform, mountain, peak, edit\n"
            "- 点操作：scatter, add, delete, fuse, divide\n"
            "- 属性：attribcreate, attribwrangle, attribpromote, attribtransfer, attribdelete\n"
            "- 噪声：noise, turbnoise, vopnoise\n"
            "- 复制：copy, copytopoints, instance\n"
            "- 合并：merge, boolean, stitch\n"
            "- 细分：subdivide, remesh, polyreduce\n"
            "- 其他：null, switch, blast, group, partition\n\n"
            "**重要提醒：**\n"
            "- 不存在 'attribrandomize'，应使用 'attribwrangle' 或 'attribcreate' + VEX 代码实现随机化\n"
            "- 旋转缩放用 pscale、orient、N、up 等标准属性\n"
            "- 如不确定节点名称或参数，强烈建议用户先使用'查询文档'功能获取官方文档\n"
            "- 在创建复杂节点网络前，可以先查询关键节点的文档确保参数正确\n"
            "- 如果你给出的是建树计划，请尽量包含 \"connections\" 字段，示例：\n"
            "  connections: [{from: n1, to: n2, input: 0}]，其中 input 表示连到目标的第几个输入口\n"
            "- 若未提供 connections，系统会尝试按顺序自动连线，但建议你显式给出连接关系\n"
            "- **生成 MCP 指令前务必检查 JSON 格式：** 确保所有字符串用双引号，数组用方括号，没有尾随逗号"
        )
        self._build_ui()
        self._wire_events()
        self._update_key_status()

    # 兼容旧环境中可能存在的属性调用差异
    def __getattr__(self, name: str):
        # 一些历史代码可能尝试调用 build_ui 或误写为 "build ui" 等
        # 直接返回 _build_ui 方法引用，避免递归
        if name in ("build_ui", "build ui", "BuildUI", "buildUi", " build ui"):
            return object.__getattribute__(self, '_build_ui')
        raise AttributeError(f"{self.__class__.__name__!r} object has no attribute {name!r}")

    def _build_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        # 顶部：提供商/模型与系统提示
        top_group = QtWidgets.QGroupBox("对话设置")
        top_layout = QtWidgets.QGridLayout(top_group)

        # 提供商
        top_layout.addWidget(QtWidgets.QLabel("提供商："), 0, 0)
        self.provider_combo = QtWidgets.QComboBox()
        self.provider_combo.addItem("OpenAI（云端）", userData='openai')
        self.provider_combo.addItem("DeepSeek（云端）", userData='deepseek')
        self.provider_combo.addItem("Ollama（本地免费）", userData='ollama')
        self.provider_combo.setCurrentIndex(1)  # 默认选择 DeepSeek
        top_layout.addWidget(self.provider_combo, 0, 1)

        # 模型
        top_layout.addWidget(QtWidgets.QLabel("模型："), 1, 0)
        self.model_combo = QtWidgets.QComboBox()
        self._openai_models = ['gpt-4o-mini', 'gpt-4o', 'gpt-4o-mini-translate']
        self._deepseek_models = ['deepseek-chat', 'deepseek-coder']
        self._ollama_models = ['llama3.1:8b-instruct', 'qwen2.5:7b-instruct', 'mistral:7b-instruct', 'phi3:mini']
        self._refresh_model_list('deepseek')  # 默认加载 DeepSeek 模型
        top_layout.addWidget(self.model_combo, 1, 1)

        top_layout.addWidget(QtWidgets.QLabel("系统提示："), 2, 0)
        self.system_prompt = QtWidgets.QLineEdit("你是一个熟悉 Houdini 的技术助理，回答尽量简洁、给出可操作建议。")
        top_layout.addWidget(self.system_prompt, 2, 1)

        # 快速响应选项
        speed_layout = QtWidgets.QHBoxLayout()
        self.fast_mode_check = QtWidgets.QCheckBox("快速响应模式")
        self.fast_mode_check.setToolTip("限制回复长度，减少等待时间（推荐日常使用）")
        self.fast_mode_check.setChecked(True)  # 默认开启
        speed_layout.addWidget(self.fast_mode_check)
        speed_layout.addStretch()
        top_layout.addLayout(speed_layout, 3, 1)

        # API Key 设置
        key_layout = QtWidgets.QHBoxLayout()
        self.key_status = QtWidgets.QLabel()
        self.btn_set_key = QtWidgets.QPushButton("设置 API Key…")
        key_layout.addWidget(self.key_status, 1)
        key_layout.addWidget(self.btn_set_key)
        top_layout.addLayout(key_layout, 4, 0, 1, 2)

        # 连接测试（支持云端和本地）
        conn_layout = QtWidgets.QHBoxLayout()
        conn_layout.addWidget(QtWidgets.QLabel("连接诊断："))
        self.btn_test_conn = QtWidgets.QPushButton("测试连接")
        self.btn_test_conn.setToolTip("测试当前提供商的 API 连接状态（可用于诊断网络或配置问题）")
        conn_layout.addWidget(self.btn_test_conn)
        conn_layout.addStretch()
        top_layout.addLayout(conn_layout, 5, 0, 1, 2)

        layout.addWidget(top_group)

        # Houdini MCP 工具（精简，仅保留读取选中节点）
        mcp_group = QtWidgets.QGroupBox("Houdini MCP 工具")
        mcp_layout = QtWidgets.QHBoxLayout(mcp_group)
        mcp_layout.setSpacing(6)
        self.btn_mcp_describe = QtWidgets.QPushButton("读取选中节点")
        self.btn_mcp_describe.setToolTip("获取当前选中节点的摘要信息，并发送给 AI")
        mcp_layout.addWidget(self.btn_mcp_describe)
        
        # 详细参数选项
        self.include_all_params_check = QtWidgets.QCheckBox("包含所有参数")
        self.include_all_params_check.setToolTip("勾选后读取节点的所有参数（包括默认值），方便 AI 精确修改")
        mcp_layout.addWidget(self.include_all_params_check)
        
        mcp_layout.addStretch()
        layout.addWidget(mcp_group)

        # 代理警告横幅（动态显示）
        self.proxy_warning = QtWidgets.QLabel()
        self.proxy_warning.setWordWrap(True)
        self.proxy_warning.setStyleSheet("""
            QLabel {
                background-color: #fff3cd;
                border: 1px solid #ffc107;
                border-radius: 4px;
                padding: 8px;
                color: #856404;
            }
        """)
        self.proxy_warning.setVisible(False)
        layout.addWidget(self.proxy_warning)

        # 历史对话
        chat_header = QtWidgets.QHBoxLayout()
        chat_label = QtWidgets.QLabel("对话历史")
        chat_label.setStyleSheet("font-weight: bold;")
        chat_header.addWidget(chat_label)
        chat_header.addStretch()
        # 新话题按钮
        self.btn_new_topic = QtWidgets.QPushButton("🔄 新话题")
        self.btn_new_topic.setToolTip("清空对话历史，开启新话题")
        self.btn_new_topic.setMaximumWidth(90)
        chat_header.addWidget(self.btn_new_topic)
        # 全屏对话按钮
        self.btn_fullscreen = QtWidgets.QPushButton("🖵 全屏对话")
        self.btn_fullscreen.setToolTip("在新窗口中查看完整对话")
        self.btn_fullscreen.setMaximumWidth(100)
        chat_header.addWidget(self.btn_fullscreen)
        # 导出按钮
        self.btn_export = QtWidgets.QPushButton("💾 导出")
        self.btn_export.setToolTip("导出对话记录为文本文件")
        self.btn_export.setMaximumWidth(80)
        chat_header.addWidget(self.btn_export)
        layout.addLayout(chat_header)
        
        self.chat_view = QtWidgets.QTextBrowser()
        self.chat_view.setOpenExternalLinks(True)
        layout.addWidget(self.chat_view, 1)

        # 输入区域
        input_layout = QtWidgets.QHBoxLayout()
        self.input_edit = QtWidgets.QTextEdit()
        self.input_edit.setPlaceholderText("在这里输入要问的问题（Ctrl+Enter 发送）…")
        self.input_edit.setFixedHeight(90)
        input_layout.addWidget(self.input_edit, 1)
        right_layout = QtWidgets.QVBoxLayout()
        self.btn_send = QtWidgets.QPushButton("发送")
        self.btn_send.setMinimumHeight(36)
        right_layout.addWidget(self.btn_send)
        
        # 旋转加载动画（初始隐藏）
        loading_container = QtWidgets.QHBoxLayout()
        loading_container.addStretch()
        self.loading_spinner = LoadingSpinner()
        self.loading_spinner.setVisible(False)
        loading_container.addWidget(self.loading_spinner)
        self.loading_label = QtWidgets.QLabel("正在请求...")
        self.loading_label.setStyleSheet("color:#1a73e8; font-weight:bold; margin-left:5px;")
        self.loading_label.setVisible(False)
        loading_container.addWidget(self.loading_label)
        loading_container.addStretch()
        right_layout.addLayout(loading_container)
        
        right_layout.addStretch()
        input_layout.addLayout(right_layout)
        layout.addLayout(input_layout)

        # 底部提示
        foot = QtWidgets.QLabel("安全提示：API Key 请使用环境变量或在本机保存到 config/houdini_ai.ini（不会上传到仓库）。")
        foot.setStyleSheet("color:#888;")
        layout.addWidget(foot)

    # 兼容旧代码：若外部调用 build_ui，则转发到 _build_ui
    def build_ui(self):
        return self._build_ui()

    def _wire_events(self):
        self.btn_send.clicked.connect(self._on_send)
        self.btn_set_key.clicked.connect(self._on_set_key)
        self.input_edit.installEventFilter(self)
        self.provider_combo.currentIndexChanged.connect(self._on_provider_changed)
        self._on_provider_changed()  # 初始化一次
        self.btn_test_conn.clicked.connect(self._on_test_connection)
        self.btn_mcp_describe.clicked.connect(self._on_mcp_describe)
        self.btn_new_topic.clicked.connect(self._on_new_topic)
        self.btn_fullscreen.clicked.connect(self._on_fullscreen)
        self.btn_export.clicked.connect(self._on_export)

    def eventFilter(self, obj, event):
        if obj is self.input_edit and event.type() == QtCore.QEvent.KeyPress:
            if (event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter)) and (event.modifiers() & QtCore.Qt.ControlModifier):
                self._on_send()
                return True
        return super().eventFilter(obj, event)

    # --- UI helpers ---
    def _update_key_status(self):
        provider = self._current_provider()
        if provider == 'ollama':
            has_key = True
        else:
            has_key = self.client.has_api_key(provider)
        if has_key:
            self.key_status.setText(f"API Key：{self.client.get_masked_key(provider)}")
            self.key_status.setStyleSheet("color:#2d7a2d;")
        else:
            self.key_status.setText("API Key：未配置（点击右侧按钮设置）")
            self.key_status.setStyleSheet("color:#a33;")

    def _append_message(self, who: str, text: str):
        from datetime import datetime
        timestamp = datetime.now().strftime("%H:%M")
        
        if who == 'You':
            who_html = f"<b style='color:#2d7a2d'>You</b> <span style='color:#999;font-size:10px'>{timestamp}</span>"
        elif who == 'Context':
            who_html = f"<b style='color:#555'>Context</b> <span style='color:#999;font-size:10px'>{timestamp}</span>"
        else:
            who_html = f"<b style='color:#1a73e8'>{who}</b> <span style='color:#999;font-size:10px'>{timestamp}</span>"
        self.chat_view.append(f"{who_html}: {text}")
        self.chat_view.verticalScrollBar().setValue(self.chat_view.verticalScrollBar().maximum())
        
        # 添加到显示历史（用于全屏窗口）
        # 将 'You' 转换为 'user'，将 bot 名称转换为 'assistant'，保留 'Context'
        if who == 'You':
            role = 'user'
        elif who in ('ChatGPT', 'DeepSeek', 'Ollama'):
            role = 'assistant'
        else:
            role = who  # Context 或其他
        
        # 从 HTML 中提取纯文本
        doc = QtGui.QTextDocument()
        doc.setHtml(text)
        plain_text = doc.toPlainText()
        self._display_history.append({'role': role, 'content': plain_text})

    def _append_context_message(self, text: str):
        if not text:
            return
        doc = QtGui.QTextDocument()
        doc.setPlainText(text)
        self._append_message('Context', doc.toHtml())

    def _current_provider(self) -> str:
        data = self.provider_combo.currentData()
        return data or 'openai'

    def _bot_name(self) -> str:
        p = self._current_provider()
        if p == 'openai':
            return 'ChatGPT'
        if p == 'deepseek':
            return 'DeepSeek'
        return 'Ollama'

    def _check_proxy_configured(self) -> bool:
        """检查系统是否配置了代理"""
        import os
        proxy_vars = ['HTTP_PROXY', 'HTTPS_PROXY', 'http_proxy', 'https_proxy']
        for var in proxy_vars:
            if os.environ.get(var):
                return True
        return False

    def _update_proxy_warning(self, provider: str):
        """根据提供商和代理状态显示警告"""
        if provider == 'deepseek' and self._check_proxy_configured():
            self.proxy_warning.setText(
                "⚠️ 提示：检测到系统配置了代理，DeepSeek 可能连接失败。"
                "建议清除代理环境变量（HTTP_PROXY/HTTPS_PROXY）或使用 Ollama 本地模型。"
            )
            self.proxy_warning.setVisible(True)
        else:
            self.proxy_warning.setVisible(False)

    def _refresh_model_list(self, provider: str):
        self.model_combo.clear()
        if provider == 'ollama':
            self.model_combo.addItems(self._ollama_models)
            self.model_combo.setToolTip('Ollama 本地模型需提前拉取，如：ollama pull llama3.1:8b-instruct')
            self.model_combo.setEditable(False)
        elif provider == 'deepseek':
            self.model_combo.addItems(self._deepseek_models)
            self.model_combo.setToolTip('DeepSeek 云端模型，将消耗 API 配额')
            self.model_combo.setEditable(False)
        else:
            self.model_combo.addItems(self._openai_models)
            self.model_combo.setToolTip('OpenAI 云端模型，将消耗 API 配额')
            self.model_combo.setEditable(False)

    def _on_provider_changed(self):
        provider = self._current_provider()
        self._refresh_model_list(provider)
        # OpenAI / DeepSeek 需要 key，Ollama 不需要
        needs_key = (provider in ('openai', 'deepseek'))
        self.key_status.setVisible(needs_key)
        self.btn_set_key.setVisible(needs_key)
        # 状态文本更新
        if needs_key:
            self._update_key_status()
        else:
            self.key_status.setText("使用本地 Ollama：无需 API Key（请先安装并启动 Ollama）")
            self.key_status.setStyleSheet("color:#2d7a2d;")
        # 测试连接按钮始终可用（云端/本地都可测试）
        self.btn_test_conn.setEnabled(True)
        
        # 显示/隐藏代理警告
        self._update_proxy_warning(provider)

    # --- actions ---
    def _on_set_key(self):
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("设置 API Key")
        v = QtWidgets.QVBoxLayout(dlg)
        provider = self._current_provider()
        if provider == 'deepseek':
            tip_text = "输入 DeepSeek API Key。建议优先使用环境变量 DEEPSEEK_API_KEY。\n可勾选保存到 config/houdini_ai.ini（仅本机）。"
        else:
            tip_text = "输入 OpenAI API Key。建议优先使用环境变量 OPENAI_API_KEY。\n可勾选保存到 config/houdini_ai.ini（仅本机）。"
        tip = QtWidgets.QLabel(tip_text)
        tip.setWordWrap(True)
        v.addWidget(tip)
        edit = QtWidgets.QLineEdit()
        edit.setEchoMode(QtWidgets.QLineEdit.Password)
        v.addWidget(edit)
        persist = QtWidgets.QCheckBox("保存到本机配置（config/houdini_ai.ini）")
        persist.setChecked(True)
        v.addWidget(persist)
        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        v.addWidget(btns)
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        if dlg.exec() == QtWidgets.QDialog.Accepted:
            key = edit.text().strip()
            if key:
                ok = self.client.set_api_key(key, persist=persist.isChecked(), provider=provider)
                if not ok:
                    QtWidgets.QMessageBox.warning(self, "提示", "保存 API Key 失败。")
                self._update_key_status()

    def _on_send(self):
        text = (self.input_edit.toPlainText() or '').strip()
        if not text:
            return
        provider = self._current_provider()
        if provider in ('openai', 'deepseek') and not self.client.has_api_key(provider):
            vendor = 'OpenAI' if provider == 'openai' else 'DeepSeek'
            QtWidgets.QMessageBox.warning(self, "提示", f"请先配置 {vendor} API Key。")
            return

        doc = QtGui.QTextDocument()
        doc.setPlainText(text)
        self._append_message('You', doc.toHtml())
        self.input_edit.clear()
        self.btn_send.setEnabled(False)
        self.loading_spinner.start()  # 启动旋转动画
        self.loading_label.setVisible(True)

        # 添加用户消息到历史
        self._conversation_history.append({'role': 'user', 'content': text})

        # 组织消息：基础系统提示 + 用户自定义系统提示 + 完整对话历史
        msgs = []
        if self._base_system_prompt:
            msgs.append({'role': 'system', 'content': self._base_system_prompt})
        sys_prompt = (self.system_prompt.text() or '').strip()
        if sys_prompt:
            msgs.append({'role': 'system', 'content': sys_prompt})
        
        # 添加完整对话历史（过滤掉非法的 role）
        for msg in self._conversation_history:
            role = msg.get('role', '')
            # 只添加 API 支持的角色
            if role in ('user', 'assistant', 'system'):
                msgs.append(msg)

        # 快速响应模式：限制 token 和超时
        # 即使非快速模式也设置合理上限,避免生成过长导致超时或中断
        if self.fast_mode_check.isChecked():
            max_tokens = 512
            timeout = 30
        else:
            max_tokens = 2048  # 设置合理上限,避免生成到一半被截断
            timeout = 120  # 增加超时时间以适应较长的生成
        
        # 使用 Python 线程而不是 QThread，避免信号连接问题
        import threading
        
        def _run_in_background():
            try:
                res = self.client.chat(
                    msgs,
                    model=self.model_combo.currentText(),
                    provider=self._current_provider(),
                    max_tokens=max_tokens,
                    timeout=timeout,
                )
            except Exception as e:
                res = {'ok': False, 'content': None, 'error': str(e), 'raw': None}
            
            # 通过信号发送结果，Qt 会自动在主线程调用槽函数
            self._responseReady.emit(res)
        
        thread = threading.Thread(target=_run_in_background, daemon=True)
        thread.start()
    
    def _after_send(self, result):
        self.btn_send.setEnabled(True)
        self.loading_spinner.stop()  # 停止旋转动画
        self.loading_label.setVisible(False)
        if result.get('ok'):
            content = result.get('content') or ''
            
            # 添加助手回复到历史
            self._conversation_history.append({'role': 'assistant', 'content': content})
            
            doc = QtGui.QTextDocument()
            doc.setPlainText(content)
            self._append_message(self._bot_name(), doc.toHtml())
            self._handle_mcp_commands(content)

            # 如果有重试信息，显示在上下文中
            info = result.get('info')
            if info:
                self._append_context_message(info)
            
            # 如果有警告信息，显示提示
            warning = result.get('warning')
            if warning:
                QtWidgets.QMessageBox.warning(self, "安全警告", warning)
        else:
            err = result.get('error') or '请求失败'
            QtWidgets.QMessageBox.warning(self, "错误", f"AI 调用失败：\n{err}")

    def _on_test_connection(self):
        provider = self._current_provider()

        # 使用进度对话框，更可靠
        progress = QtWidgets.QProgressDialog(f"正在测试 {self._bot_name()} 连接...", None, 0, 0, self)
        progress.setWindowTitle("测试连接")
        progress.setWindowModality(QtCore.Qt.WindowModal)
        progress.setCancelButton(None)
        progress.setMinimumDuration(0)
        progress.setValue(0)
        
        # 使用 QTimer 在下一个事件循环中执行测试，避免阻塞
        def _run_test():
            try:
                if provider == 'ollama':
                    res = self.client.ping_ollama()
                else:
                    res = self.client.test_connection(provider)
                
                # 确保对话框关闭
                progress.close()
                progress.deleteLater()
                
                # 显示结果
                if provider == 'ollama':
                    if res.get('ok'):
                        QtWidgets.QMessageBox.information(
                            self, "连接成功",
                            f"已连接到 Ollama：\n{res.get('base_url')}\n版本：{res.get('version')}"
                        )
                    else:
                        QtWidgets.QMessageBox.warning(
                            self, "连接失败",
                            f"无法连接到 Ollama：\n{res.get('base_url')}\n错误：{res.get('error')}"
                        )
                else:
                    if res.get('ok'):
                        QtWidgets.QMessageBox.information(
                            self, "连接成功",
                            f"{self._bot_name()} API 连接正常\n{res.get('url')}\n状态：{res.get('status')}"
                        )
                    else:
                        err_msg = f"{self._bot_name()} 连接失败\n\n错误：{res.get('error')}\nURL: {res.get('url')}\n\n详情：{res.get('details', '')}"
                        QtWidgets.QMessageBox.warning(self, "连接失败", err_msg)
            except Exception as e:
                progress.close()
                progress.deleteLater()
                QtWidgets.QMessageBox.critical(self, "测试失败", f"连接测试发生异常：\n{str(e)}")
        
        # 延迟执行，让进度对话框先显示
        QtCore.QTimer.singleShot(100, _run_test)

    def _on_mcp_describe(self):
        # 根据复选框决定是否读取所有参数
        include_all_params = self.include_all_params_check.isChecked()
        ok, message = self.mcp.describe_selection(include_all_params=include_all_params)
        if ok:
            # 将节点信息添加到对话历史中（作为用户消息的一部分）
            self._append_context_message(message)
            # 同时添加到对话历史，让 AI 能够看到
            self._conversation_history.append({'role': 'user', 'content': f"[节点信息]\n{message}"})
            
            if not self.input_edit.toPlainText().strip():
                # 提取节点名称和类型以生成更明确的问题
                import re
                match = re.search(r'=== 节点 (\S+) ===\n完整类型：(\S+)', message)
                if match:
                    node_name, node_type = match.groups()
                    if include_all_params:
                        self.input_edit.setPlainText(
                            f"上面的 {node_type} 节点（{node_name}）已读取所有参数。请解释其作用，或根据参数值分析当前配置。"
                        )
                    else:
                        self.input_edit.setPlainText(
                            f"上面的 {node_type} 节点（{node_name}）是做什么的？请解释其作用和典型使用场景。"
                        )
                else:
                    self.input_edit.setPlainText("请解释上述节点的作用和常见用途。")
                self.input_edit.selectAll()
            self.chat_view.ensureCursorVisible()
        else:
            QtWidgets.QMessageBox.information(self, "提示", message)

    def _on_mcp_search(self):
        keyword, ok = QtWidgets.QInputDialog.getText(
            self,
            "搜索节点类型",
            "输入关键字（名称或描述的一部分）：",
        )
        if not ok:
            return
        keyword = keyword.strip()
        if not keyword:
            QtWidgets.QMessageBox.information(self, "提示", "请输入搜索关键字。")
            return

        success, message = self.mcp.search_nodes(keyword)
        if success:
            full_message = f"节点搜索（{keyword}）：\n{message}"
            self._append_context_message(full_message)
            # 将搜索结果添加到对话历史，以便AI可以看到
            self._conversation_history.append({'role': 'user', 'content': f"[搜索结果]\n{full_message}"})
        else:
            QtWidgets.QMessageBox.information(self, "提示", message)

    def _on_mcp_docs(self):
        """查询 Houdini 官方节点文档"""
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("查询节点文档")
        dialog.setModal(True)
        layout = QtWidgets.QFormLayout(dialog)
        layout.setSpacing(8)
        layout.setContentsMargins(12, 12, 12, 12)

        # 节点类型输入
        node_type_edit = QtWidgets.QLineEdit()
        node_type_edit.setPlaceholderText("例如：scatter, copy, attribwrangle")
        layout.addRow("节点类型：", node_type_edit)

        # 节点类别下拉框
        category_combo = QtWidgets.QComboBox()
        category_combo.addItems(["sop", "obj", "dop", "vop", "cop2", "chop", "lop", "top"])
        layout.addRow("节点类别：", category_combo)

        # 按钮
        btn_layout = QtWidgets.QHBoxLayout()
        btn_ok = QtWidgets.QPushButton("查询")
        btn_cancel = QtWidgets.QPushButton("取消")
        btn_ok.clicked.connect(dialog.accept)
        btn_cancel.clicked.connect(dialog.reject)
        btn_layout.addWidget(btn_ok)
        btn_layout.addWidget(btn_cancel)
        layout.addRow("", btn_layout)

        node_type_edit.setFocus()

        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return

        node_type = node_type_edit.text().strip()
        if not node_type:
            QtWidgets.QMessageBox.information(self, "提示", "请输入节点类型。")
            return

        # 智能解析：如果输入包含 '/' (如 sop/labs::splatter)，自动提取类别和节点名
        if '/' in node_type:
            parts = node_type.split('/', 1)
            category = parts[0]
            node_type = parts[1]
        else:
            category = category_combo.currentText()

        # 显示进度
        progress = QtWidgets.QProgressDialog("正在查询文档...", "取消", 0, 0, self)
        progress.setWindowModality(QtCore.Qt.WindowModal)
        progress.setMinimumDuration(500)
        progress.setValue(0)

        success, message = self.mcp.search_documentation(node_type, category)
        progress.close()

        if success:
            self._append_context_message(f"文档查询结果：\n{message}")
            # 将文档内容添加到对话历史
            self._conversation_history.append({'role': 'user', 'content': f"[文档查询]\n{message}"})
        else:
            QtWidgets.QMessageBox.warning(self, "查询失败", message)

    def _on_mcp_create(self):
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("创建节点")
        dialog.setModal(True)
        layout = QtWidgets.QFormLayout(dialog)
        layout.setSpacing(8)
        layout.setContentsMargins(12, 12, 12, 12)

        type_edit = QtWidgets.QLineEdit()
        type_edit.setPlaceholderText("例如：attribwrangle 或 sop/attribwrangle")
        layout.addRow("节点类型：", type_edit)

        name_edit = QtWidgets.QLineEdit()
        name_edit.setPlaceholderText("可选，留空使用默认命名")
        layout.addRow("节点名称：", name_edit)

        button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        layout.addRow(button_box)
        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)

        if dialog.exec() != QtWidgets.QDialog.Accepted:
            return

        type_hint = type_edit.text().strip()
        node_name = name_edit.text().strip() or None
        if not type_hint:
            QtWidgets.QMessageBox.information(self, "提示", "节点类型不能为空。")
            return

        success, message = self.mcp.create_node(type_hint, node_name)
        if success:
            QtWidgets.QMessageBox.information(self, "已创建", message)
            self._append_context_message(f"节点创建：{message}")
        else:
            QtWidgets.QMessageBox.warning(self, "创建失败", message)

    def _handle_mcp_commands(self, content: str):
        if not content:
            return

        matches = re.findall(r"```mcp\s*([\s\S]*?)```", content)
        if not matches:
            return

        for block in matches:
            block_str = block.strip()
            if not block_str:
                continue
            try:
                command = json.loads(block_str)
            except json.JSONDecodeError as exc:
                # 提供更详细的错误信息
                error_msg = f"❌ MCP 指令 JSON 解析失败\n\n"
                
                # 检查是否是生成中断导致的不完整 JSON
                if exc.msg in ('Expecting value', 'Unterminated string', 'Expecting property name enclosed in double quotes'):
                    error_msg += "⚠️ 检测到 JSON 不完整，可能是 AI 生成被中断\n\n"
                    error_msg += "可能原因：\n"
                    error_msg += "1. 响应内容过长，超出 token 限制被截断\n"
                    error_msg += "2. 网络连接中断或超时\n"
                    error_msg += "3. API 服务器提前结束响应\n\n"
                    error_msg += "建议：\n"
                    error_msg += "- 尝试简化请求（如只创建部分节点）\n"
                    error_msg += "- 开启『快速模式』减少系统提示长度\n"
                    error_msg += "- 重新发送请求重试\n\n"
                
                error_msg += f"错误位置：第 {exc.lineno} 行，第 {exc.colno} 列\n"
                error_msg += f"错误提示：{exc.msg}\n\n"
                # 显示出错位置附近的内容
                if exc.pos and exc.pos < len(block_str):
                    start = max(0, exc.pos - 30)
                    end = min(len(block_str), exc.pos + 30)
                    context = block_str[start:end]
                    error_msg += f"出错位置附近：...{context}...\n\n"
                else:
                    # 显示 JSON 的最后几个字符
                    if len(block_str) > 50:
                        error_msg += f"JSON 末尾：...{block_str[-50:]}\n\n"
                
                error_msg += "其他常见错误：\n"
                error_msg += "- 字符串值未用双引号包裹\n"
                error_msg += "- 数组未用方括号 []\n"
                error_msg += "- 多个值之间缺少逗号或有多余逗号\n"
                self._append_context_message(error_msg)
                continue

            if not isinstance(command, dict):
                self._append_context_message("MCP 指令格式无效（需要 JSON 对象）。")
                continue

            action = command.get('action')
            if action == 'create_node':
                node_type = command.get('type') or command.get('node_type')
                node_name = command.get('name')
                # 支持 "parameters" 和 "parms" 两种写法
                params_dict = command.get('parameters') or command.get('parms')
                params = params_dict if isinstance(params_dict, dict) else None
                success, message = self.mcp.create_node(node_type or '', node_name, params)
                self._append_context_message(message)
                if not success:
                    QtWidgets.QMessageBox.warning(self, "MCP 执行失败", message)
                continue

            if action == 'create_nodes':
                plan = command.get('plan') if isinstance(command.get('plan'), dict) else command
                success, message = self.mcp.create_network(plan)
                self._append_context_message(message)
                if not success:
                    QtWidgets.QMessageBox.warning(self, "MCP 执行失败", message)
                continue

            if action == 'connect_nodes':
                # 支持字段别名：from/src/output_node_path, to/dst/input_node_path, input/input_index
                output_path = (
                    command.get('output_node_path')
                    or command.get('from')
                    or command.get('src')
                    or command.get('output')
                )
                input_path = (
                    command.get('input_node_path')
                    or command.get('to')
                    or command.get('dst')
                    or command.get('input_node')
                )
                input_index = command.get('input_index', command.get('input', 0))
                if not output_path or not input_path:
                    self._append_context_message("连接失败：缺少输出或输入节点路径（from/to）。")
                else:
                    ok, msg = self.mcp.connect_nodes(str(output_path), str(input_path), int(input_index or 0))
                    self._append_context_message(msg)
                    if not ok:
                        QtWidgets.QMessageBox.warning(self, "MCP 执行失败", msg)
                continue

            if action == 'set_parameter' or action == 'set_param' or action == 'update_parameter':
                # 支持 { "action": "set_parameter", "node_path": "/obj/geo1/wrangle1", "param_name": "snippet", "value": "..." }
                node_path = command.get('node_path') or command.get('node') or command.get('path')
                param_name = command.get('param_name') or command.get('parameter') or command.get('param')
                value = command.get('value')
                
                if not node_path:
                    self._append_context_message("设置参数失败：缺少 node_path。")
                elif not param_name:
                    self._append_context_message("设置参数失败：缺少 param_name。")
                elif value is None:
                    self._append_context_message("设置参数失败：缺少 value。")
                else:
                    ok, msg = self.mcp.set_parameter(str(node_path), str(param_name), value)
                    self._append_context_message(msg)
                    if not ok:
                        QtWidgets.QMessageBox.warning(self, "MCP 执行失败", msg)
                continue

            if action == 'delete_node':
                # 支持 { "action": "delete_node", "node_path": "/obj/geo1/null1" }
                node_path = command.get('node_path') or command.get('path') or command.get('node')
                if not node_path:
                    self._append_context_message("删除失败：缺少 node_path。")
                else:
                    ok, msg = self.mcp.delete_node_by_path(str(node_path))
                    self._append_context_message(msg)
                    if not ok:
                        QtWidgets.QMessageBox.warning(self, "MCP 执行失败", msg)
                continue

            if action == 'delete_selection' or action == 'delete_selected':
                ok, msg = self.mcp.delete_selected()
                self._append_context_message(msg)
                if not ok:
                    QtWidgets.QMessageBox.warning(self, "MCP 执行失败", msg)
                continue

            if action == 'delete_nodes':
                # 支持按路径或名称删除
                node_paths = command.get('node_paths') or command.get('paths')
                node_ids = command.get('node_ids') or command.get('names')
                parent_path = command.get('parent_path')
                if node_paths and isinstance(node_paths, list):
                    ok, msg = self.mcp.delete_nodes_by_paths([str(p) for p in node_paths])
                elif node_ids and isinstance(node_ids, list):
                    ok, msg = self.mcp.delete_nodes_by_names([str(n) for n in node_ids], parent_path=parent_path)
                else:
                    ok, msg = False, "删除失败：请提供 node_paths（完整路径）或 node_ids（名称）。"
                self._append_context_message(msg)
                if not ok:
                    QtWidgets.QMessageBox.warning(self, "MCP 执行失败", msg)
                continue

            if action in ('delete_all','clear_children','clear_network'):
                ok, msg = self.mcp.delete_all_children(parent_path=command.get('parent_path'))
                self._append_context_message(msg)
                if not ok:
                    QtWidgets.QMessageBox.warning(self, "MCP 执行失败", msg)
                continue

            # 友好的错误提示，建议正确的动作名称
            error_msg = f"❌ 未知的 MCP 动作：{action}\n\n"
            error_msg += "✅ 可用的 MCP 动作只有以下 4 个（必须精确匹配）：\n"
            error_msg += "1. create_nodes - 创建节点网络\n"
            error_msg += "2. set_parameter - 修改节点参数（完整拼写！）\n"
            error_msg += "3. connect_nodes - 连接节点\n"
            error_msg += "4. delete_node - 删除节点\n\n"
            
            # 常见错误提示
            if action in ('set_parm', 'set_parms', 'set_param', 'set_params', 'update_param', 'modify_param', 'update_parm'):
                error_msg += "💡 提示：您使用了错误的拼写！正确的是 'set_parameter'（完整单词，不能缩写）\n"
                error_msg += "正确格式：{\"action\":\"set_parameter\",\"node_path\":\"...\",\"param_name\":\"...\",\"value\":...}"
            elif action in ('create_node', 'add_node'):
                error_msg += "💡 提示：您可能想使用 'create_nodes'（创建节点）"
            elif action in ('connect', 'link_nodes'):
                error_msg += "💡 提示：您可能想使用 'connect_nodes'（连接节点）"
            elif action in ('delete', 'remove_node'):
                error_msg += "💡 提示：您可能想使用 'delete_node'（删除节点）"
            
            self._append_context_message(error_msg)

    def _on_new_topic(self):
        """开启新话题"""
        if not self._conversation_history:
            QtWidgets.QMessageBox.information(self, "提示", "当前没有对话历史。")
            return
        
        reply = QtWidgets.QMessageBox.question(
            self,
            "确认清空",
            "确定要清空当前对话历史并开启新话题吗？\n这将无法恢复当前对话。",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
        )
        
        if reply == QtWidgets.QMessageBox.Yes:
            self._conversation_history.clear()
            self.chat_view.clear()
            self.input_edit.clear()
            self.chat_view.append("<i style='color:#999'>已清空对话历史，开始新话题...</i>")

    def _on_fullscreen(self):
        """打开交互式大窗口聊天界面（实时可发可收）。"""
        # 保持强引用避免被 GC，非模态显示
        if not hasattr(self, '_chat_windows'):
            self._chat_windows = []
        win = ChatWindow(client=self.client, mcp=self.mcp, parent=self)
        try:
            # 传递显示历史（包含 Context 消息）
            win.load_history(self._display_history)
        except Exception:
            pass
        win.setModal(False)
        win.show()
        self._chat_windows.append(win)
        # 清理关闭的窗口引用
        def _cleanup():
            self._chat_windows = [w for w in self._chat_windows if w.isVisible()]
        win.destroyed.connect(_cleanup)

    def _on_new_topic(self):
        """开启新话题"""
        if not self._conversation_history:
            QtWidgets.QMessageBox.information(self, "提示", "当前没有对话历史。")
            return
        
        reply = QtWidgets.QMessageBox.question(
            self,
            "确认",
            "确定要清空当前对话并开启新话题吗？",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No
        )
        
        if reply == QtWidgets.QMessageBox.Yes:
            self._conversation_history.clear()
            self._display_history.clear()
            self.chat_view.clear()
            self._append_context_message(
                "✓ 已开启新话题，对话历史已清空。\n\n"
                "💡 提示：系统提示词（包括 MCP 指令说明）会在您发送下一条消息时自动添加。\n"
                "如果 AI 没有使用 MCP 指令，可以明确告诉它『请使用 MCP 指令创建节点』。"
            )

    def _on_export(self):
        """导出对话"""
        if not self._conversation_history:
            QtWidgets.QMessageBox.information(self, "提示", "当前没有对话可以导出。")
            return
        from datetime import datetime
        default_name = f"houdini_ai_chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        file_path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "导出对话记录",
            default_name,
            "文本文件 (*.txt);;Markdown 文件 (*.md);;所有文件 (*.*)"
        )
        if not file_path:
            return
        try:
            plain_text = self.chat_view.toPlainText()
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(f"# Houdini AI 对话记录\n")
                f.write(f"导出时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"提供商：{self._bot_name()}\n")
                f.write(f"模型：{self.model_combo.currentText()}\n")
                f.write(f"\n{'='*60}\n\n")
                f.write(plain_text)
            QtWidgets.QMessageBox.information(self, "导出成功", f"对话已保存到：\n{file_path}")
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "导出失败", f"保存文件时出错：\n{str(e)}")
